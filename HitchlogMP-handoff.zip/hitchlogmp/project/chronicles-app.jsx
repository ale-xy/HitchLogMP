// chronicles-app.jsx — host shell for Chronicles screens

const { useState: useS4, useEffect: useE4 } = React;

const CHRON_TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "screen": "list",
  "editMode": "new",
  "listState": "filled",
  "darkMode": false
}/*EDITMODE-END*/;

function ChroniclesApp() {
  const [tweaks, setTweak] = useTweaks(CHRON_TWEAK_DEFAULTS);
  const [snack, setSnack] = useS4(null);
  const [logoutOpen, setLogoutOpen] = useS4(false);
  const [deleteOpen, setDeleteOpen] = useS4(false);
  const [editingChronicle, setEditingChronicle] = useS4(null);

  // Dark mode
  useE4(() => {
    if (tweaks.darkMode) {
      document.documentElement.style.setProperty('--background', '#11131A');
      document.documentElement.style.setProperty('--on-background', '#E4E2E9');
      document.documentElement.style.setProperty('--surface', '#191C24');
      document.documentElement.style.setProperty('--on-surface', '#E4E2E9');
      document.documentElement.style.setProperty('--surface-variant', '#252835');
      document.documentElement.style.setProperty('--on-surface-variant', '#C5C6D0');
      document.documentElement.style.setProperty('--outline', '#8E909A');
      document.documentElement.style.setProperty('--outline-variant', '#363946');
      document.documentElement.style.setProperty('--surface-container-low', '#1A1D26');
      document.documentElement.style.setProperty('--surface-container', '#1F2230');
      document.documentElement.style.setProperty('--primary', '#B0C4FF');
      document.documentElement.style.setProperty('--on-primary', '#012078');
      document.documentElement.style.setProperty('--primary-container', '#002C9F');
      document.documentElement.style.setProperty('--on-primary-container', '#D9E2FF');
    } else {
      ['background','on-background','surface','on-surface','surface-variant','on-surface-variant','outline','outline-variant','surface-container-low','surface-container','primary','on-primary','primary-container','on-primary-container']
        .forEach(k => document.documentElement.style.removeProperty('--' + k));
    }
  }, [tweaks.darkMode]);

  const chronicles = tweaks.listState === 'empty' ? [] : SAMPLE_CHRONICLES;

  // Navigate based on tweak
  const showList = tweaks.screen === 'list';
  const showEdit = tweaks.screen === 'edit';

  const goToEdit = (chronicle, mode) => {
    setEditingChronicle(chronicle || null);
    setTweak({ screen: 'edit', editMode: mode || 'new' });
  };
  const goToList = () => {
    setEditingChronicle(null);
    setTweak('screen', 'list');
  };

  return (
    <>
      <PhoneFrame>
        {showList && (
          <LogListScreen
            chronicles={chronicles}
            onOpen={(c) => setSnack(`Открыть: ${c.name}`)}
            onEdit={(c) => goToEdit(c, 'edit')}
            onCreate={() => goToEdit(null, 'new')}
            onLogout={() => setLogoutOpen(true)}
          />
        )}
        {showEdit && (
          <EditLogScreen
            key={`${tweaks.editMode}-${editingChronicle?.id || 'new'}`}
            mode={tweaks.editMode}
            initial={editingChronicle}
            onClose={goToList}
            onSave={(data) => {
              setSnack(`Сохранено: ${data.name}`);
              goToList();
            }}
            onDelete={() => setDeleteOpen(true)}
          />
        )}
        <LogoutDialog
          open={logoutOpen}
          onConfirm={() => { setLogoutOpen(false); setSnack('Выход из аккаунта'); }}
          onCancel={() => setLogoutOpen(false)}
        />
        <DeleteChronicleDialog
          open={deleteOpen}
          name={editingChronicle?.name || ''}
          onConfirm={() => { setDeleteOpen(false); setSnack('Хроника удалена'); goToList(); }}
          onCancel={() => setDeleteOpen(false)}
        />
        {snack && <ChronSnackbar message={snack} onDismiss={() => setSnack(null)} />}
      </PhoneFrame>

      <TweaksPanel>
        <TweakSection label="Навигация" />
        <TweakRadio
          label="Экран"
          value={tweaks.screen}
          onChange={v => setTweak('screen', v)}
          options={[
            { value: 'list', label: 'Список' },
            { value: 'edit', label: 'Создание/Ред.' },
          ]}
        />
        {showEdit && (
          <TweakRadio
            label="Режим"
            value={tweaks.editMode}
            onChange={v => {
              setTweak('editMode', v);
              if (v === 'edit' && !editingChronicle) {
                setEditingChronicle(SAMPLE_CHRONICLES[0]);
              } else if (v === 'new') {
                setEditingChronicle(null);
              }
            }}
            options={[
              { value: 'new', label: 'Новая' },
              { value: 'edit', label: 'Редактирование' },
            ]}
          />
        )}
        {showList && (
          <TweakRadio
            label="Список"
            value={tweaks.listState}
            onChange={v => setTweak('listState', v)}
            options={[
              { value: 'filled', label: 'С данными' },
              { value: 'empty', label: 'Пустой' },
            ]}
          />
        )}
        <TweakSection label="Тема" />
        <TweakToggle
          label="Тёмная тема"
          value={tweaks.darkMode}
          onChange={v => setTweak('darkMode', v)}
        />
      </TweaksPanel>
    </>
  );
}

function ChronSnackbar({ message, onDismiss }) {
  useE4(() => {
    const t = setTimeout(onDismiss, 2800);
    return () => clearTimeout(t);
  }, [message, onDismiss]);
  return (
    <div style={{
      position: 'absolute', left: 16, right: 16, bottom: 32,
      background: '#322F35', color: '#F4EFF4',
      padding: '14px 16px', borderRadius: 4,
      fontSize: 14, lineHeight: '20px',
      boxShadow: '0 6px 12px rgba(0,0,0,0.2)',
      zIndex: 80,
    }}>{message}</div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<ChroniclesApp />);
