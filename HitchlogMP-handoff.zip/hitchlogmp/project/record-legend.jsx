// record-legend.jsx — visual reference + palette explorer for RECORD_TYPES

const { useMemo: useLM, useState: useLS, useEffect: useLE } = React;

/* ──────────────────────────────────────────────────────────────
   THEME TOKENS (page chrome)
   ────────────────────────────────────────────────────────────── */
const DARK_TOKENS = {
  '--background': '#11131A', '--on-background': '#E4E2E9',
  '--surface': '#191C24', '--on-surface': '#E4E2E9',
  '--surface-variant': '#252835', '--on-surface-variant': '#C5C6D0',
  '--outline': '#8E909A', '--outline-variant': '#363946',
  '--surface-container-low': '#1A1D26', '--surface-container': '#1F2230',
  '--primary': '#B0C4FF', '--on-primary': '#012078',
  '--primary-container': '#002C9F', '--on-primary-container': '#D9E2FF',
  '--secondary': '#FFCC00', '--on-secondary': '#1A1A00',
  '--secondary-container': '#4A4500', '--on-secondary-container': '#FFF0A0',
  '--tertiary': '#BCC2FF', '--on-tertiary': '#0E1B66',
  '--error': '#FFB4AB', '--on-error': '#690005',
  '--error-container': '#93000A', '--on-error-container': '#FFDAD6',
};
const LIGHT_TOKENS = {
  '--background': '#F8F9FF', '--on-background': '#1A1B20',
  '--surface': '#FFFFFF', '--on-surface': '#1A1B20',
  '--surface-variant': '#E4E5F0', '--on-surface-variant': '#44464F',
  '--outline': '#74757F', '--outline-variant': '#C4C5D0',
  '--surface-container-low': '#F2F3FA', '--surface-container': '#ECEDF4',
  '--primary': '#1A3A8F', '--on-primary': '#FFFFFF',
  '--primary-container': '#D9E2FF', '--on-primary-container': '#001258',
  '--secondary': '#FFCC00', '--on-secondary': '#1A1A00',
  '--secondary-container': '#FFF0A0', '--on-secondary-container': '#1A1400',
  '--tertiary': '#5C6BC0', '--on-tertiary': '#FFFFFF',
  '--error': '#BA1A1A', '--on-error': '#FFFFFF',
  '--error-container': '#FFDAD6', '--on-error-container': '#410002',
};
function applyTheme(dark) {
  const root = document.documentElement;
  const set = dark ? DARK_TOKENS : LIGHT_TOKENS;
  if (dark) Object.entries(DARK_TOKENS).forEach(([k, v]) => root.style.setProperty(k, v));
  else Object.keys(DARK_TOKENS).forEach(k => root.style.removeProperty(k));
  return set;
}

/* ──────────────────────────────────────────────────────────────
   LOG COLOR PALETTE (shared with Log List) + dark-mode tints
   Each color: deep `solid`, brighter `bright`, plus lifted dark tones.
   ────────────────────────────────────────────────────────────── */
/* Each entry mirrors LogColorPair(lightThemeColor, darkThemeColor): `light` is the
   chip fill in light theme, `dark` in dark theme. Dark values stay fully saturated
   (not pastel) so chips match the Log List tags. fg = glyph/text color per theme. */
const PAL = {
  BLUE:    { label: 'Blue',    light: '#1A3A8F', dark: '#3358D4', lightFg: '#FFFFFF', darkFg: '#FFFFFF' },
  CYAN:    { label: 'Cyan',    light: '#0288D1', dark: '#039BE5', lightFg: '#FFFFFF', darkFg: '#FFFFFF' },
  GREEN:   { label: 'Green',   light: '#2E7D32', dark: '#43A047', lightFg: '#FFFFFF', darkFg: '#FFFFFF' },
  PURPLE:  { label: 'Purple',  light: '#6A1B9A', dark: '#8E24AA', lightFg: '#FFFFFF', darkFg: '#FFFFFF' },
  YELLOW:  { label: 'Yellow',  light: '#FFC400', dark: '#FFC400', lightFg: '#1A1400', darkFg: '#1A1400' },
  RED:     { label: 'Red',     light: '#C62828', dark: '#D32F2F', lightFg: '#FFFFFF', darkFg: '#FFFFFF' },
  BLACK:   { label: 'Neutral·dark',  light: '#212121', dark: '#424242', lightFg: '#FFFFFF', darkFg: '#FFFFFF' },
  WHITE:   { label: 'Neutral·light', light: '#E8E8E8', dark: '#E0E0E0', lightFg: '#1A1B20', darkFg: '#1A1B20' },
  // Added to the shared palette (same light=deep / dark=brighter philosophy)
  ORANGE:  { label: 'Orange',  light: '#E65100', dark: '#FB8C00', lightFg: '#FFFFFF', darkFg: '#2A1500' },
  MAGENTA: { label: 'Magenta', light: '#AD1457', dark: '#D81B60', lightFg: '#FFFFFF', darkFg: '#FFFFFF' },
};

// Lighten a hex toward white by `amt` (0..1) — used for the brighter pair tone
function lighten(hex, amt) {
  const n = parseInt(hex.slice(1), 16);
  const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  const mix = (c) => Math.round(c + (255 - c) * amt);
  return '#' + [mix(r), mix(g), mix(b)].map(c => c.toString(16).padStart(2, '0')).join('');
}
// Pick a readable glyph color for a given background
function pickFg(hex) {
  const n = parseInt(hex.slice(1), 16);
  const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return lum > 0.62 ? '#1A1B20' : '#FFFFFF';
}

// Proposed mapping: one hue per activity family; `end:true` = closing half of a pair
const PROPOSED = {
  START:       { c: 'BLUE'    },
  CHECKPOINT:  { c: 'BLUE'    },
  FINISH:      { c: 'BLUE'    },
  LIFT:        { c: 'YELLOW'  },
  GET_OFF:     { c: 'YELLOW',  end: true },
  WALK:        { c: 'ORANGE'  },
  WALK_END:    { c: 'ORANGE',  end: true },
  REST_ON:     { c: 'GREEN'   },
  REST_OFF:    { c: 'GREEN',   end: true },
  OFFSIDE_ON:  { c: 'MAGENTA' },
  OFFSIDE_OFF: { c: 'MAGENTA', end: true },
  RETIRE:      { c: 'PURPLE'  },
  MEET:        { c: 'BLACK'   },
  FREE_TEXT:   { c: 'WHITE'   },
};

// Resolve a proposed chip → { bg, fg, stroke } given dark + pair treatment ('outline' | 'variant')
function proposedChip(typeId, dark, treatment) {
  const e = PROPOSED[typeId];
  const p = PAL[e.c];
  const bg = dark ? p.dark : p.light;
  const fg = dark ? p.darkFg : p.lightFg;
  if (e.end) {
    if (treatment === 'outline') {
      return { bg: 'var(--surface)', fg: bg, stroke: bg };
    }
    // brighter pair tone
    const alt = lighten(bg, 0.20);
    return { bg: alt, fg: pickFg(alt) };
  }
  return { bg, fg };
}

function proposedHexes(typeId, dark, treatment) {
  const ch = proposedChip(typeId, dark, treatment);
  return { bg: ch.bg.startsWith('#') ? ch.bg : (ch.stroke || ''), fg: ch.fg, stroke: ch.stroke };
}

/* ──────────────────────────────────────────────────────────────
   CURRENT (token-role) system — for side-by-side comparison
   ────────────────────────────────────────────────────────────── */
const ROLE_INFO = {
  'primary':    { name: 'primary',      tokens: '--primary / --on-primary' },
  'secondary':  { name: 'secondary',    tokens: '--secondary / --on-secondary' },
  'tertiary':   { name: 'tertiary',     tokens: '--tertiary / --on-tertiary' },
  'error':      { name: 'error (soft)', tokens: '--error-container + --error stroke' },
  'error-bold': { name: 'error (bold)', tokens: '--error / --on-error' },
  'outline':    { name: 'outline',      tokens: '--surface + --outline-variant stroke' },
  'surface':    { name: 'surface',      tokens: '--surface-variant / --on-surface-variant' },
};
function resolveVar(cssValue, tokens) {
  if (!cssValue || !cssValue.startsWith('var(')) return cssValue || '';
  const name = cssValue.slice(4, -1).trim();
  return (tokens[name] || '').trim() || cssValue;
}

/* ──────────────────────────────────────────────────────────────
   PRESENTATION
   ────────────────────────────────────────────────────────────── */
function Chip({ bg, fg, stroke, icon, size = 48 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      background: bg, color: fg,
      border: stroke ? `1.5px solid ${stroke}` : 'none',
      display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
    }}>
      <span className="material-symbols-outlined" style={{ fontSize: Math.round(size * 0.54), color: fg }}>{icon}</span>
    </div>
  );
}

function Swatch({ hex, stroke }) {
  return (
    <span style={{
      width: 16, height: 16, borderRadius: 4, flexShrink: 0,
      background: hex || 'transparent',
      border: stroke ? `1.5px solid ${stroke}` : '1px solid rgba(127,127,127,0.35)',
    }} />
  );
}

function Row({ label, children }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
      <span style={{ width: 44, flexShrink: 0, color: 'var(--on-surface-variant)', opacity: 0.7 }}>{label}</span>
      <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>{children}</div>
    </div>
  );
}

function Tag({ children, tone = 'warn' }) {
  const tones = {
    warn: { bg: 'var(--secondary-container)', fg: 'var(--on-secondary-container)' },
    info: { bg: 'var(--primary-container)',   fg: 'var(--on-primary-container)' },
  };
  const t = tones[tone];
  return (
    <span style={{
      fontFamily: 'Roboto', fontSize: 10.5, fontWeight: 500, letterSpacing: 0.3,
      padding: '2px 8px', borderRadius: 100, background: t.bg, color: t.fg, whiteSpace: 'nowrap',
    }}>{children}</span>
  );
}

function LegendCard({ def, chip, meta, dupIcon }) {
  return (
    <div style={{
      background: 'var(--surface)', border: '1px solid var(--outline-variant)',
      borderRadius: 16, padding: 16, display: 'flex', flexDirection: 'column', gap: 14,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <Chip {...chip} icon={def.icon} />
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: 17, fontWeight: 500, color: 'var(--on-surface)', lineHeight: 1.2 }}>{def.label}</div>
          <div style={{ fontFamily: "'Roboto Mono', monospace", fontSize: 12, color: 'var(--on-surface-variant)', marginTop: 3 }}>{def.id}</div>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, fontFamily: "'Roboto Mono', monospace", fontSize: 12 }}>
        <Row label="icon">
          <span style={{ color: 'var(--on-surface)' }}>{def.icon}</span>
          {dupIcon && <Tag>общий значок</Tag>}
        </Row>
        <Row label={meta.roleLabel}>
          <span style={{ color: 'var(--on-surface)' }}>{meta.colorName}</span>
          {meta.treatment && <Tag tone="info">{meta.treatment}</Tag>}
        </Row>
        <Row label="цвета">
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <Swatch hex={meta.bgHex} stroke={chip.stroke} />
            <span style={{ color: 'var(--on-surface-variant)' }}>{meta.bgHex || '—'}</span>
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <Swatch hex={meta.fgHex} />
            <span style={{ color: 'var(--on-surface-variant)' }}>{meta.fgHex || '—'}</span>
          </span>
        </Row>
      </div>
    </div>
  );
}

/* Segmented control */
function Segmented({ value, onChange, options }) {
  return (
    <div style={{
      display: 'inline-flex', padding: 3, gap: 2,
      background: 'var(--surface-variant)', borderRadius: 100,
    }}>
      {options.map(o => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            onClick={() => onChange(o.value)}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              height: 34, padding: '0 14px', border: 'none', borderRadius: 100,
              cursor: 'pointer', fontFamily: 'Roboto', fontSize: 13, fontWeight: 500,
              background: active ? 'var(--surface)' : 'transparent',
              color: active ? 'var(--on-surface)' : 'var(--on-surface-variant)',
              boxShadow: active ? '0 1px 2px rgba(0,0,0,0.18)' : 'none',
              transition: 'background 120ms',
            }}
          >
            {o.icon && <span className="material-symbols-outlined" style={{ fontSize: 18, color: active ? 'var(--primary)' : 'inherit' }}>{o.icon}</span>}
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

function ControlGroup({ label, children }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <span style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.6, textTransform: 'uppercase', color: 'var(--on-surface-variant)', opacity: 0.85 }}>{label}</span>
      {children}
    </div>
  );
}

/* Color-token / palette reference at the bottom */
function PaletteReference({ source, tokens, dark }) {
  if (source === 'proposed') {
    const order = ['BLUE', 'YELLOW', 'ORANGE', 'GREEN', 'MAGENTA', 'PURPLE', 'BLACK', 'WHITE'];
    return (
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 10 }}>
        {order.map(k => {
          const p = PAL[k];
          const bg = dark ? p.dark : p.light;
          const fg = dark ? p.darkFg : p.lightFg;
          return (
            <div key={k} style={{ border: '1px solid var(--outline-variant)', borderRadius: 12, overflow: 'hidden', fontFamily: "'Roboto Mono', monospace", fontSize: 11.5 }}>
              <div style={{ background: bg, color: fg, padding: '14px 12px', display: 'flex', flexDirection: 'column', gap: 2 }}>
                <span style={{ fontWeight: 500 }}>{p.label}</span>
                <span style={{ opacity: 0.85 }}>{bg}</span>
              </div>
              <div style={{ padding: '8px 12px', color: 'var(--on-surface-variant)', background: 'var(--surface)' }}>
                light {p.light} · dark {p.dark}
              </div>
            </div>
          );
        })}
      </div>
    );
  }
  const pairs = [
    ['--primary', '--on-primary'], ['--primary-container', '--on-primary-container'],
    ['--secondary', '--on-secondary'], ['--secondary-container', '--on-secondary-container'],
    ['--tertiary', '--on-tertiary'], ['--error', '--on-error'],
    ['--error-container', '--on-error-container'], ['--surface', '--on-surface'],
    ['--surface-variant', '--on-surface-variant'], ['--outline', '--outline-variant'],
    ['--background', '--on-background'],
  ];
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 10 }}>
      {pairs.map(([bg, fg]) => {
        const bgHex = resolveVar(`var(${bg})`, tokens), fgHex = resolveVar(`var(${fg})`, tokens);
        return (
          <div key={bg} style={{ border: '1px solid var(--outline-variant)', borderRadius: 12, overflow: 'hidden', fontFamily: "'Roboto Mono', monospace", fontSize: 11.5 }}>
            <div style={{ background: bgHex, color: fgHex, padding: '14px 12px', display: 'flex', flexDirection: 'column', gap: 2 }}>
              <span style={{ fontWeight: 500 }}>{bg}</span>
              <span style={{ opacity: 0.8 }}>{bgHex}</span>
            </div>
            <div style={{ padding: '8px 12px', color: 'var(--on-surface-variant)', background: 'var(--surface)' }}>
              on: {fg} · {fgHex}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function RecordTypeLegend() {
  const types = Object.values(RECORD_TYPES);

  const [dark, setDark] = useLS(() => localStorage.getItem('hitchlog-legend-theme') === 'dark');
  const [source, setSource] = useLS(() => localStorage.getItem('hitchlog-legend-source') || 'proposed');
  const [treatment, setTreatment] = useLS(() => localStorage.getItem('hitchlog-legend-pair') || 'outline');

  const [tokens, setTokens] = useLS(LIGHT_TOKENS);
  useLE(() => {
    setTokens(applyTheme(dark));
    localStorage.setItem('hitchlog-legend-theme', dark ? 'dark' : 'light');
  }, [dark]);
  useLE(() => localStorage.setItem('hitchlog-legend-source', source), [source]);
  useLE(() => localStorage.setItem('hitchlog-legend-pair', treatment), [treatment]);

  const dupIcons = useLM(() => {
    const count = {};
    types.forEach(t => { count[t.icon] = (count[t.icon] || 0) + 1; });
    return new Set(Object.keys(count).filter(k => count[k] > 1));
  }, []);

  // Build per-type chip + meta for the active source
  const cards = types.map(def => {
    if (source === 'proposed') {
      const chip = proposedChip(def.id, dark, treatment);
      const e = PROPOSED[def.id];
      const hexes = proposedHexes(def.id, dark, treatment);
      const treat = e.end ? (treatment === 'outline' ? 'контур' : 'светлее') : 'основной';
      return {
        def, chip, dupIcon: dupIcons.has(def.icon),
        meta: { roleLabel: 'цвет', colorName: PAL[e.c].label, treatment: treat, bgHex: hexes.bg, fgHex: hexes.fg },
      };
    }
    const c = chipColors(def.color);
    const role = ROLE_INFO[def.color] || { name: def.color };
    const bgHex = resolveVar(c.bg, tokens), fgHex = resolveVar(c.fg, tokens);
    return {
      def, dupIcon: dupIcons.has(def.icon),
      chip: { bg: c.bg, fg: c.fg, stroke: c.stroke },
      meta: { roleLabel: 'роль', colorName: role.name, treatment: null, bgHex, fgHex },
    };
  });

  return (
    <div style={{ maxWidth: 1100, margin: '0 auto', padding: '40px 28px 64px' }}>
      <header style={{ marginBottom: 24, display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap' }}>
        <div>
          <div style={{ fontFamily: "'Roboto Mono', monospace", fontSize: 12, letterSpacing: 1, textTransform: 'uppercase', color: 'var(--primary)' }}>HitchLog · справочник</div>
          <h1 style={{ fontSize: 32, fontWeight: 700, color: 'var(--on-surface)', margin: '8px 0 6px', letterSpacing: -0.5 }}>Типы записей</h1>
          <p style={{ fontSize: 15, lineHeight: 1.5, color: 'var(--on-surface-variant)', margin: 0, maxWidth: 640 }}>
            Все {types.length} типов записей — значок, подпись и цвет. Переключайте палитру, тему и стиль парных событий, чтобы сравнить.
          </p>
        </div>
        <button
          onClick={() => setDark(d => !d)}
          style={{
            display: 'inline-flex', alignItems: 'center', gap: 8, height: 40, padding: '0 16px 0 12px',
            background: 'var(--surface)', color: 'var(--on-surface)', border: '1px solid var(--outline-variant)',
            borderRadius: 100, cursor: 'pointer', fontFamily: 'Roboto', fontSize: 13, fontWeight: 500, flexShrink: 0,
          }}
        >
          <span className="material-symbols-outlined" style={{ fontSize: 20, color: 'var(--primary)' }}>{dark ? 'light_mode' : 'dark_mode'}</span>
          {dark ? 'Светлая' : 'Тёмная'}
        </button>
      </header>

      {/* Controls */}
      <div style={{
        display: 'flex', flexWrap: 'wrap', gap: 24, alignItems: 'flex-end',
        padding: 16, background: 'var(--surface-container-low)', borderRadius: 16, marginBottom: 28,
      }}>
        <ControlGroup label="Палитра">
          <Segmented
            value={source} onChange={setSource}
            options={[
              { value: 'current',  label: 'Текущая',    icon: 'history' },
              { value: 'proposed', label: 'Предложение', icon: 'palette' },
            ]}
          />
        </ControlGroup>
        {source === 'proposed' && (
          <ControlGroup label="Парные события (off / конец)">
            <Segmented
              value={treatment} onChange={setTreatment}
              options={[
                { value: 'outline', label: 'Контур' },
                { value: 'variant', label: 'Светлее' },
              ]}
            />
          </ControlGroup>
        )}
      </div>

      {/* Type grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 14 }}>
        {cards.map(card => <LegendCard key={card.def.id} {...card} />)}
      </div>

      {/* Palette reference */}
      <h2 style={{ fontSize: 22, fontWeight: 700, color: 'var(--on-surface)', margin: '48px 0 4px', letterSpacing: -0.3 }}>
        {source === 'proposed' ? 'Палитра журналов' : 'Цветовые токены'}
      </h2>
      <p style={{ fontSize: 14, lineHeight: 1.5, color: 'var(--on-surface-variant)', margin: '0 0 20px' }}>
        {source === 'proposed'
          ? 'Те же цвета, что и для журналов (LogColorPair). Каждый цвет имеет отдельное насыщенное значение для светлой и тёмной темы.'
          : 'Material 3 палитра, на которую ссылаются роли выше.'}
      </p>
      <PaletteReference source={source} tokens={tokens} dark={dark} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<RecordTypeLegend />);
