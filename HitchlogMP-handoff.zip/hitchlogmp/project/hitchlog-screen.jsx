// hitchlog-screen.jsx — HitchLogScreen (chronicle view)

const { useState, useMemo, useRef, useEffect } = React;

// Material 3 status bar (custom, themed to surface)
function StatusBar() {
  return (
    <div style={{
      height: 32, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 20px', position: 'relative', flexShrink: 0,
      background: 'var(--surface)', color: 'var(--on-surface)',
      fontSize: 13, fontWeight: 500, letterSpacing: 0.1, fontFamily: 'Roboto',
    }}>
      <span>9:42</span>
      <div style={{
        position: 'absolute', left: '50%', top: 6, transform: 'translateX(-50%)',
        width: 18, height: 18, borderRadius: '50%', background: '#1d1b20',
      }} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
        {/* signal */}
        <svg width="15" height="11" viewBox="0 0 15 11"><path d="M1 9h2v2H1zm3-2h2v4H4zm3-2h2v6H7zm3-2h2v8h-2zm3-2h2v10h-2z" fill="currentColor"/></svg>
        {/* wifi */}
        <svg width="14" height="10" viewBox="0 0 14 10"><path d="M7 9.5L0 3a10 10 0 0114 0L7 9.5z" fill="currentColor"/></svg>
        {/* battery */}
        <svg width="22" height="11" viewBox="0 0 22 11"><rect x="0.5" y="0.5" width="19" height="10" rx="2" fill="none" stroke="currentColor" strokeWidth="1"/><rect x="2" y="2" width="14" height="7" rx="1" fill="currentColor"/><rect x="20" y="3.5" width="1.5" height="4" rx="0.5" fill="currentColor"/></svg>
      </div>
    </div>
  );
}

// Top app bar — small variant per Material 3
function TopAppBar({ title, subtitle, onBack, scrolled }) {
  return (
    <div style={{
      flexShrink: 0,
      background: scrolled ? 'var(--surface-container)' : 'var(--surface)',
      transition: 'background 200ms',
      borderBottom: scrolled ? '1px solid var(--outline-variant)' : '1px solid transparent',
    }}>
      <div style={{ height: 64, display: 'flex', alignItems: 'center', padding: '4px 4px' }}>
        <IconButton icon="arrow_back" onClick={onBack} />
        <div style={{ flex: 1, minWidth: 0, paddingLeft: 4 }}>
          <div style={{ fontSize: 22, lineHeight: '28px', fontWeight: 500, color: 'var(--on-surface)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{title}</div>
          {subtitle && (
            <div style={{ fontSize: 12, lineHeight: '16px', color: 'var(--on-surface-variant)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{subtitle}</div>
          )}
        </div>
        <IconButton icon="more_vert" />
      </div>
    </div>
  );
}

// Material 3 icon button — 48dp hit target, ripple on press
function IconButton({ icon, onClick, color = 'var(--on-surface-variant)', size = 24 }) {
  const [pressed, setPressed] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        width: 48, height: 48, border: 'none', background: 'transparent',
        borderRadius: '50%', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', flexShrink: 0,
      }}
    >
      <span style={{
        position: 'absolute', inset: 4, borderRadius: '50%',
        background: pressed ? 'rgba(26,59,143,0.12)' : 'transparent',
        transition: 'background 120ms',
      }} />
      <span className="material-symbols-outlined" style={{ fontSize: size, color, position: 'relative' }}>{icon}</span>
    </button>
  );
}

// Sticky date header — full-width pill on surface-variant
function DateHeader({ iso }) {
  return (
    <div style={{
      position: 'sticky', top: 0, zIndex: 2,
      background: 'var(--background)',
      padding: '12px 16px 6px',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        background: 'var(--surface-variant)', color: 'var(--on-surface-variant)',
        padding: '8px 16px', borderRadius: 8,
        fontSize: 12, fontWeight: 500, letterSpacing: 0.5, textTransform: 'uppercase',
      }}>
        <span>{formatDateHeader(iso)}</span>
      </div>
    </div>
  );
}

function pluralRecord(n) {
  const m10 = n % 10, m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return 'запись';
  if ([2,3,4].includes(m10) && ![12,13,14].includes(m100)) return 'записи';
  return 'записей';
}

// Single record row — list item with leading icon chip + headline + supporting + trailing time
function RecordItem({ record, onClick, isLast, connector }) {
  const def = RECORD_TYPES[record.type];
  const c = chipColors(def);
  const [pressed, setPressed] = useState(false);

  return (
    <div
      onClick={() => onClick && onClick(record)}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        display: 'flex', alignItems: 'flex-start', gap: 16,
        padding: '12px 16px', minHeight: 72,
        background: pressed ? 'rgba(26,59,143,0.08)' : 'var(--surface)',
        cursor: 'pointer', position: 'relative',
        borderBottom: isLast ? 'none' : '1px solid var(--outline-variant)',
      }}
    >
      {/* leading icon + connector rail */}
      <div style={{ position: 'relative', width: 40, flexShrink: 0, alignSelf: 'stretch' }}>
        <div style={{
          width: 40, height: 40, borderRadius: '50%',
          background: c.bg, color: c.fg,
          border: c.stroke ? `1px solid ${c.stroke}` : 'none',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          position: 'relative', zIndex: 1,
        }}>
          <span className="material-symbols-outlined" style={{ fontSize: 22, color: c.fg }}>{def.icon}</span>
        </div>
        {connector && (
          <div style={{
            position: 'absolute', left: 19, top: 40, bottom: -12, width: 2,
            background: 'var(--outline-variant)',
          }} />
        )}
      </div>

      {/* content */}
      <div style={{ flex: 1, minWidth: 0, paddingTop: 2 }}>
        <div style={{ fontSize: 16, lineHeight: '24px', fontWeight: 500, color: 'var(--on-surface)' }}>
          {def.label}
        </div>
        {record.text && (
          <div style={{
            fontSize: 14, lineHeight: '20px', color: 'var(--on-surface-variant)',
            marginTop: 2, overflow: 'hidden', display: '-webkit-box',
            WebkitLineClamp: 2, WebkitBoxOrient: 'vertical',
          }}>
            {record.text}
          </div>
        )}
      </div>

      {/* trailing time */}
      <div style={{
        fontSize: 12, fontWeight: 500, letterSpacing: 0.5,
        color: 'var(--on-surface-variant)', paddingTop: 11, fontVariantNumeric: 'tabular-nums',
      }}>
        {formatTime(record.time)}
      </div>
    </div>
  );
}

// Extended FAB — Primary container, anchored bottom-right
function ExtendedFab({ onClick, label = 'Запись', icon = 'add' }) {
  const [pressed, setPressed] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        position: 'absolute', right: 16, bottom: 24,
        height: 56, padding: '0 20px 0 16px',
        background: 'var(--primary)', color: 'var(--on-primary)',
        border: 'none', borderRadius: 16, cursor: 'pointer',
        display: 'flex', alignItems: 'center', gap: 12,
        fontFamily: 'Roboto', fontSize: 14, fontWeight: 500, letterSpacing: 0.1,
        boxShadow: pressed
          ? '0 1px 2px rgba(0,0,0,0.2), 0 1px 3px rgba(0,0,0,0.1)'
          : '0 4px 8px rgba(0,0,0,0.15), 0 1px 3px rgba(0,0,0,0.1)',
        transform: pressed ? 'translateY(1px)' : 'translateY(0)',
        transition: 'transform 120ms, box-shadow 120ms',
        zIndex: 10,
      }}
    >
      <span className="material-symbols-outlined" style={{ fontSize: 20, color: 'var(--on-primary)' }}>{icon}</span>
      {label}
    </button>
  );
}

// Race summary card — at-a-glance status: counters + live state badge
// `meta` (optional): { totalCheckpoints, restBudgetMinutes, divisibilitiesTotal }
function SummaryCard({ records, meta = {} }) {
  const [restMode, setRestMode] = useState('used'); // 'used' | 'left'

  const lifts = records.filter(r => r.type === 'LIFT').length;
  const cps = records.filter(r => r.type === 'CHECKPOINT').length;

  // Determine current status from chronologically-last record
  const sorted = [...records].sort((a, b) => a.time.localeCompare(b.time));
  const last = sorted[sorted.length - 1];
  const lastOpen = (() => {
    // walk back to find last "opening" event not closed yet
    let inCar = null, rest = null, offside = null;
    for (const r of sorted) {
      if (r.type === 'LIFT') inCar = r;
      else if (r.type === 'GET_OFF') inCar = null;
      else if (r.type === 'REST_ON') rest = r;
      else if (r.type === 'REST_OFF') rest = null;
      else if (r.type === 'OFFSIDE_ON') offside = r;
      else if (r.type === 'OFFSIDE_OFF') offside = null;
    }
    if (offside) return { kind: 'OFFSIDE', since: offside.time };
    if (rest)    return { kind: 'REST',    since: rest.time };
    if (inCar)   return { kind: 'IN_CAR',  since: inCar.time };
    return null;
  })();
  const finished = sorted.some(r => r.type === 'FINISH');
  const retired  = sorted.some(r => r.type === 'RETIRE');

  // Used rest = sum of REST_ON → REST_OFF intervals (closed) + open interval to "now" (last record time)
  const restMinutes = (() => {
    let total = 0; let onAt = null;
    for (const r of sorted) {
      if (r.type === 'REST_ON') onAt = new Date(r.time);
      else if (r.type === 'REST_OFF' && onAt) {
        total += (new Date(r.time) - onAt) / 60000;
        onAt = null;
      }
    }
    if (onAt && last) total += (new Date(last.time) - onAt) / 60000;
    return Math.max(0, Math.round(total));
  })();
  const restStr = formatBudget(restMinutes);

  // Divisibilities used = number of distinct REST_ON occurrences (each rest = 1 use)
  const divUsed = sorted.filter(r => r.type === 'REST_ON').length;

  // Toggle between used vs remaining
  const hasBudget = !!meta.restBudgetMinutes;
  const hasDiv = meta.divisibilitiesTotal != null;
  const restLeft = hasBudget ? Math.max(0, meta.restBudgetMinutes - restMinutes) : null;
  const divLeft  = hasDiv ? Math.max(0, meta.divisibilitiesTotal - divUsed) : null;
  const showLeft = restMode === 'left';

  let restValue, restLabel;
  if (showLeft) {
    const t = hasBudget ? formatBudget(restLeft) : restStr;
    restValue = hasDiv ? `${t}/${divLeft}` : t;
    restLabel = 'остаток';
  } else {
    restValue = hasDiv ? `${restStr}/${divUsed}` : restStr;
    restLabel = 'использовано';
  }

  return (
    <div style={{
      margin: '12px 16px 4px', padding: '16px',
      background: 'var(--primary-container)', color: 'var(--on-primary-container)',
      borderRadius: 12,
    }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
        <Stat value={lifts} leading="directions_car" />
        <Stat
          value={meta.totalCheckpoints ? `${cps}/${meta.totalCheckpoints}` : `${cps}`}
          leading="location_on"
        />
        <Stat
          value={restValue}
          align="right"
          leading="hotel"
          onClick={() => setRestMode(showLeft ? 'used' : 'left')}
        />
      </div>

      {/* Live status badge */}
      {(lastOpen || finished || retired) && (
        <div style={{ marginTop: 12, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {finished && <StatusBadge kind="FINISH" />}
          {retired  && <StatusBadge kind="RETIRE" />}
          {!finished && !retired && lastOpen && <StatusBadge kind={lastOpen.kind} since={lastOpen.since} />}
        </div>
      )}
    </div>
  );
}

function formatBudget(min) {
  return `${String(Math.floor(min / 60)).padStart(2,'0')}:${String(min % 60).padStart(2,'0')}`;
}

function StatusBadge({ kind, since }) {
  const map = {
    IN_CAR:  { label: 'В машине',   icon: 'directions_car', bg: 'var(--secondary)',         fg: 'var(--on-secondary)' },
    REST:    { label: 'Rest',       icon: 'hotel',          bg: 'var(--surface-variant)',   fg: 'var(--on-surface-variant)' },
    OFFSIDE: { label: 'Вне игры',   icon: 'pause_circle',   bg: 'var(--error-container)',   fg: 'var(--on-error-container)' },
    FINISH:  { label: 'Финишировали', icon: 'sports_score', bg: 'var(--primary)',           fg: 'var(--on-primary)' },
    RETIRE:  { label: 'Сход',       icon: 'cancel',         bg: 'var(--error)',             fg: 'var(--on-error)' },
  };
  const s = map[kind]; if (!s) return null;
  let sinceLabel = null;
  if (since) {
    const d = new Date(since);
    sinceLabel = `с ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
  }
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '6px 10px 6px 8px',
      background: s.bg, color: s.fg, borderRadius: 100,
      fontSize: 12, fontWeight: 500, letterSpacing: 0.3,
    }}>
      <span className="material-symbols-outlined" style={{ fontSize: 16, color: s.fg }}>{s.icon}</span>
      <span>{s.label}</span>
      {sinceLabel && <span style={{ opacity: 0.75, fontVariantNumeric: 'tabular-nums' }}>· {sinceLabel}</span>}
    </div>
  );
}

function pluralLift(n) {
  const m10 = n % 10, m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return 'машина';
  if ([2,3,4].includes(m10) && ![12,13,14].includes(m100)) return 'машины';
  return 'машин';
}

function Stat({ value, label, small, onClick, trailing, leading, align = 'left' }) {
  const [pressed, setPressed] = useState(false);
  const interactive = !!onClick;
  const justify = align === 'right' ? 'flex-end' : align === 'center' ? 'center' : 'flex-start';
  return (
    <div
      onClick={onClick}
      onMouseDown={() => interactive && setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        cursor: interactive ? 'pointer' : 'default',
        margin: interactive ? '-6px -8px' : 0, padding: interactive ? '6px 8px' : 0,
        borderRadius: 8,
        background: interactive && pressed ? 'rgba(0,0,0,0.06)' : 'transparent',
        transition: 'background 120ms',
        userSelect: 'none',
        textAlign: align,
      }}
    >
      <div style={{
        fontSize: 20, fontWeight: 500, lineHeight: 1.1,
        color: 'var(--on-primary-container)', fontVariantNumeric: 'tabular-nums',
        display: 'flex', alignItems: 'center', gap: 6,
        justifyContent: justify,
      }}>
        {leading && (
          <span className="material-symbols-outlined" style={{
            fontSize: 20,
            color: 'var(--on-primary-container)',
            opacity: 0.85,
          }}>{leading}</span>
        )}
        <span>{value}</span>
      </div>
      {label && (
        <div style={{
          fontSize: 11, color: 'var(--on-primary-container)', opacity: 0.75, marginTop: 2,
          display: 'flex', alignItems: 'center',
          justifyContent: justify,
        }}>
          <span>{label}</span>
          {trailing}
        </div>
      )}
    </div>
  );
}

// Empty state — primary CTA "Старт" + secondary link to all types
function EmptyState({ onStart, onMore }) {
  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', padding: '32px 24px', textAlign: 'center',
    }}>
      <span className="material-symbols-outlined" style={{ fontSize: 64, color: 'var(--outline-variant)' }}>directions_walk</span>
      <div style={{ marginTop: 16, fontSize: 16, fontWeight: 500, color: 'var(--on-surface)' }}>Хроника пуста</div>

      {/* Primary CTA */}
      <button
        onClick={onStart}
        style={{
          marginTop: 28,
          height: 56, padding: '0 28px 0 22px',
          background: 'var(--primary)', color: 'var(--on-primary)',
          border: 'none', borderRadius: 28, cursor: 'pointer',
          display: 'inline-flex', alignItems: 'center', gap: 12,
          fontFamily: 'Roboto', fontSize: 16, fontWeight: 500, letterSpacing: 0.15,
          boxShadow: '0 4px 8px rgba(26,59,143,0.25), 0 1px 3px rgba(0,0,0,0.1)',
        }}
      >
        <span className="material-symbols-outlined" style={{ fontSize: 24, color: 'var(--on-primary)' }}>timer</span>
        Старт
      </button>

      {/* Secondary — link to all types */}
      <button
        onClick={onMore}
        style={{
          marginTop: 12, padding: '10px 16px', minHeight: 40,
          background: 'transparent', border: 'none',
          color: 'var(--primary)', cursor: 'pointer',
          fontFamily: 'Roboto', fontSize: 14, fontWeight: 500, letterSpacing: 0.1,
        }}
      >
        Другой тип записи
      </button>
    </div>
  );
}

// Quick-actions dock — pinned to bottom of screen, context-aware, collapsible.
// Top 2 actions large, next 3 medium. Predicts next likely action from `lastType`.
function QuickActions({ lastType, collapsed, onToggle, onPick, onMore }) {
  // Priority ladder: which types are most likely next, given the previous record?
  const ladder = useMemo(() => {
    const base = ['LIFT', 'GET_OFF', 'CHECKPOINT', 'WALK', 'MEET', 'REST_ON', 'FREE_TEXT', 'FINISH'];
    const map = {
      // Just on the road, waiting / walking → next is a lift
      START:       ['LIFT', 'WALK', 'CHECKPOINT', 'MEET', 'FREE_TEXT'],
      GET_OFF:     ['LIFT', 'WALK', 'CHECKPOINT', 'REST_ON', 'MEET', 'FREE_TEXT'],
      WALK_END:    ['LIFT', 'CHECKPOINT', 'REST_ON', 'MEET', 'FREE_TEXT'],
      // In a car → next is getting out
      LIFT:        ['GET_OFF', 'CHECKPOINT', 'OFFSIDE_ON', 'MEET', 'FREE_TEXT'],
      // Walking → end the walk
      WALK:        ['WALK_END', 'CHECKPOINT', 'MEET', 'FREE_TEXT'],
      // Paired toggles
      REST_ON:     ['REST_OFF', 'FREE_TEXT', 'MEET'],
      REST_OFF:    ['LIFT', 'WALK', 'CHECKPOINT', 'FREE_TEXT'],
      OFFSIDE_ON:  ['OFFSIDE_OFF', 'FREE_TEXT'],
      OFFSIDE_OFF: ['LIFT', 'CHECKPOINT', 'FREE_TEXT'],
      CHECKPOINT:  ['LIFT', 'WALK', 'GET_OFF', 'MEET', 'REST_ON', 'FREE_TEXT'],
      MEET:        ['LIFT', 'CHECKPOINT', 'FREE_TEXT'],
      FINISH:      ['FREE_TEXT'],
      FREE_TEXT:   base,
    };
    return (map[lastType] || base);
  }, [lastType]);

  // Top 2 large primary, next 3 medium, rest as small inline chips → "ещё"
  const top = ladder[0];
  const second = ladder[1];
  const medium = ladder.slice(2, 5);

  // When collapsed: a single Extended FAB anchored bottom-right.
  // Body = create the next likely record; trailing chevron = expand the ladder.
  if (collapsed) {
    const nextDef = RECORD_TYPES[ladder[0]];
    return (
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-end',
        padding: '0 12px 12px', pointerEvents: 'none', zIndex: 20,
      }}>
        <div style={{
          pointerEvents: 'auto',
          display: 'inline-flex', alignItems: 'stretch',
          height: 56, borderRadius: 16,
          background: 'var(--primary)', color: 'var(--on-primary)',
          boxShadow: '0 4px 12px rgba(26,59,143,0.30), 0 1px 3px rgba(0,0,0,0.10)',
          overflow: 'hidden',
        }}>
          <button
            onClick={() => onPick(ladder[0])}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 10,
              padding: '0 18px',
              background: 'transparent', color: 'var(--on-primary)',
              border: 'none', cursor: 'pointer',
              fontFamily: 'Roboto', fontSize: 15, fontWeight: 500, letterSpacing: 0.1,
            }}
          >
            <span className="material-symbols-outlined" style={{ fontSize: 22 }}>add</span>
            <span>{nextDef ? nextDef.label : 'Запись'}</span>
          </button>
          <div style={{ width: 1, background: 'rgba(255,255,255,0.25)', alignSelf: 'stretch', margin: '10px 0' }} />
          <button
            onClick={onToggle}
            aria-label="Развернуть быстрые действия"
            style={{
              width: 48, display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              background: 'transparent', color: 'var(--on-primary)',
              border: 'none', cursor: 'pointer',
            }}
          >
            <span className="material-symbols-outlined" style={{ fontSize: 22 }}>keyboard_arrow_up</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{
      position: 'absolute', left: 0, right: 0, bottom: 0,
      background: 'var(--surface)',
      borderTop: '1px solid var(--outline-variant)',
      borderTopLeftRadius: 20, borderTopRightRadius: 20,
      padding: '6px 12px 12px',
      boxShadow: '0 -4px 16px rgba(0,0,0,0.06)',
      zIndex: 20,
    }}>
      {/* Header — collapse button only */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'flex-end',
        padding: '0 4px 4px', userSelect: 'none',
      }}>
        <button
          onClick={onToggle}
          style={{
            width: 32, height: 32, borderRadius: '50%', border: 'none',
            background: 'transparent', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}
        >
          <span className="material-symbols-outlined" style={{ fontSize: 22, color: 'var(--on-surface-variant)' }}>keyboard_arrow_down</span>
        </button>
      </div>

      {/* Row 1 — two large buttons */}
      <div style={{ display: 'flex', gap: 8 }}>
        <BigActionButton type={top} onClick={() => onPick(top)} highlight />
        {second && <BigActionButton type={second} onClick={() => onPick(second)} />}
      </div>

      {/* Row 2 — three medium + "more" tile */}
      <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
        {medium.map(t => (
          <MediumActionButton key={t} type={t} onClick={() => onPick(t)} />
        ))}
        <MoreTile onClick={onMore} />
      </div>
    </div>
  );
}

function MoreTile({ onClick }) {
  const [pressed, setPressed] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        flex: 1, minWidth: 0, height: 44,
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
        padding: '0 8px',
        background: 'var(--primary-container)',
        color: 'var(--on-primary-container)',
        border: 'none', borderRadius: 12, cursor: 'pointer',
        fontFamily: 'Roboto', fontSize: 12, fontWeight: 500,
        transform: pressed ? 'scale(0.97)' : 'scale(1)', transition: 'transform 120ms',
      }}
    >
      <span className="material-symbols-outlined" style={{ fontSize: 18, color: 'var(--primary)' }}>apps</span>
      Ещё
    </button>
  );
}

function NextHint({ type, compact }) {
  const def = RECORD_TYPES[type];
  if (!def) return null;
  const c = chipColors(def);
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: compact ? '2px 8px 2px 2px' : '4px 10px 4px 4px', borderRadius: 100,
      background: compact ? 'transparent' : 'var(--surface-variant)',
      color: 'var(--on-surface-variant)',
      fontSize: 12, fontWeight: 500, letterSpacing: 0,
      textTransform: 'none',
      marginLeft: compact ? 4 : 0,
    }}>
      <span style={{
        width: 22, height: 22, borderRadius: '50%', background: c.bg, color: c.fg,
        border: c.stroke ? `1px solid ${c.stroke}` : 'none',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <span className="material-symbols-outlined" style={{ fontSize: 14, color: c.fg }}>{def.icon}</span>
      </span>
      {def.label}
    </div>
  );
}

function BigActionButton({ type, onClick, highlight }) {
  const def = RECORD_TYPES[type];
  const c = chipColors(def);
  const [pressed, setPressed] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        flex: 1, minHeight: 64,
        display: 'flex', flexDirection: 'column', alignItems: 'flex-start', justifyContent: 'center', gap: 4,
        padding: '10px 14px',
        background: highlight ? 'var(--primary-container)' : 'var(--surface-variant)',
        color: highlight ? 'var(--on-primary-container)' : 'var(--on-surface)',
        border: 'none', borderRadius: 12, cursor: 'pointer',
        fontFamily: 'Roboto', textAlign: 'left',
        transform: pressed ? 'scale(0.98)' : 'scale(1)',
        transition: 'transform 120ms, background 120ms',
        position: 'relative',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, width: '100%' }}>
        <span style={{
          width: 32, height: 32, borderRadius: '50%', background: c.bg, color: c.fg,
          border: c.stroke ? `1px solid ${c.stroke}` : 'none',
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        }}>
          <span className="material-symbols-outlined" style={{ fontSize: 18, color: c.fg }}>{def.icon}</span>
        </span>
        <div style={{ flex: 1, fontSize: 15, fontWeight: 500, color: highlight ? 'var(--on-primary-container)' : 'var(--on-surface)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {def.label}
        </div>
      </div>
    </button>
  );
}

function MediumActionButton({ type, onClick }) {
  const def = RECORD_TYPES[type];
  const c = chipColors(def);
  const [pressed, setPressed] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        flex: 1, minWidth: 0, height: 44,
        display: 'flex', alignItems: 'center', gap: 6,
        padding: '0 10px',
        background: 'transparent',
        color: 'var(--on-surface)',
        border: '1px solid var(--outline-variant)', borderRadius: 12, cursor: 'pointer',
        fontFamily: 'Roboto',
        transform: pressed ? 'scale(0.97)' : 'scale(1)', transition: 'transform 120ms, background 120ms',
      }}
    >
      <span style={{
        width: 24, height: 24, borderRadius: '50%', background: c.bg, color: c.fg,
        border: c.stroke ? `1px solid ${c.stroke}` : 'none',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
      }}>
        <span className="material-symbols-outlined" style={{ fontSize: 14, color: c.fg }}>{def.icon}</span>
      </span>
      <div style={{ flex: 1, minWidth: 0, fontSize: 12, fontWeight: 500, color: 'var(--on-surface)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', textAlign: 'left' }}>
        {def.label}
      </div>
    </button>
  );
}

// Main screen
function HitchLogScreen({
  records, log, isEmpty, showSummary,
  quickCollapsed, onToggleQuick,
  onRecordClick, onAddRecord, onPickType,
}) {
  const [scrolled, setScrolled] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => setScrolled(el.scrollTop > 4);
    el.addEventListener('scroll', onScroll);
    return () => el.removeEventListener('scroll', onScroll);
  }, []);

  // Group records by date
  const groups = useMemo(() => {
    const sorted = [...records].sort((a, b) => a.time.localeCompare(b.time));
    const map = new Map();
    for (const r of sorted) {
      const k = dateKey(r.time);
      if (!map.has(k)) map.set(k, []);
      map.get(k).push(r);
    }
    return [...map.entries()].map(([k, items]) => ({ key: k, iso: items[0].time, items }));
  }, [records]);

  // Last record (chronologically) drives quick-action prediction
  const lastType = useMemo(() => {
    if (!records.length) return null;
    const sorted = [...records].sort((a, b) => a.time.localeCompare(b.time));
    return sorted[sorted.length - 1].type;
  }, [records]);

  // Auto-scroll to bottom on mount and when records change so the latest entry is visible
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [records.length]);

  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden',
      background: 'var(--background)', position: 'relative',
    }}>
      <TopAppBar title={log.name} subtitle={log.team} scrolled={scrolled} onBack={() => {}} />

      <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden' }}>
        {isEmpty ? (
          <EmptyState
            onStart={() => onPickType && onPickType('START')}
            onMore={onAddRecord}
          />
        ) : (
          <>
            {showSummary && <SummaryCard records={records} meta={log.meta} />}

            {groups.map(group => (
              <div key={group.key}>
                <DateHeader iso={group.iso} />
                <div style={{ background: 'var(--surface)', margin: '0 16px', borderRadius: 12, overflow: 'hidden', border: '1px solid var(--outline-variant)' }}>
                  {group.items.map((r, i) => (
                    <RecordItem
                      key={r.id}
                      record={r}
                      isLast={i === group.items.length - 1}
                      connector={false}
                      onClick={onRecordClick}
                    />
                  ))}
                </div>
              </div>
            ))}

            {/* bottom spacer so the dock doesn't overlap the last item */}
            <div style={{ height: quickCollapsed ? 88 : 240 }} />
          </>
        )}
      </div>

      {!isEmpty && (
        <QuickActions
          lastType={lastType}
          collapsed={quickCollapsed}
          onToggle={onToggleQuick}
          onPick={(t) => onPickType && onPickType(t)}
          onMore={onAddRecord}
        />
      )}
    </div>
  );
}

Object.assign(window, {
  HitchLogScreen, StatusBar, TopAppBar, IconButton,
  DateHeader, RecordItem, ExtendedFab, SummaryCard, EmptyState,
  QuickActions, BigActionButton, MediumActionButton, NextHint,
});
