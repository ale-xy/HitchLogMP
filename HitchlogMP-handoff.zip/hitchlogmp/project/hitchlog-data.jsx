// hitchlog-data.jsx — record types + sample chronicle data

// Record types per DESIGN_SYSTEM.md
const RECORD_TYPES = {
  START:       { id: 'START',       label: 'Старт',         icon: 'timer',            color: 'primary'  },
  LIFT:        { id: 'LIFT',        label: 'Посадка',       icon: 'directions_car',   color: 'secondary'},
  GET_OFF:     { id: 'GET_OFF',     label: 'Выход',         icon: 'logout',           color: 'secondary'},
  WALK:        { id: 'WALK',        label: 'ППХ',           icon: 'directions_walk',  color: 'tertiary' },
  WALK_END:    { id: 'WALK_END',    label: 'Конец ППХ',     icon: 'accessibility_new', color: 'tertiary' },
  CHECKPOINT:  { id: 'CHECKPOINT',  label: 'КП',            icon: 'location_on',      color: 'primary'  },
  MEET:        { id: 'MEET',        label: 'Встреча',       icon: 'groups',           color: 'outline'  },
  REST_ON:     { id: 'REST_ON',     label: 'Rest on',       icon: 'hotel',            color: 'surface'  },
  REST_OFF:    { id: 'REST_OFF',    label: 'Rest off',      icon: 'play_arrow',       color: 'surface'  },
  OFFSIDE_ON:  { id: 'OFFSIDE_ON',  label: 'Вне игры',      icon: 'pause_circle',     color: 'error'    },
  OFFSIDE_OFF: { id: 'OFFSIDE_OFF', label: 'Вне игры off',  icon: 'play_arrow',       color: 'error'    },
  FINISH:      { id: 'FINISH',      label: 'Финиш',         icon: 'sports_score',     color: 'primary'  },
  RETIRE:      { id: 'RETIRE',      label: 'Сход',          icon: 'block',            color: 'error-bold' },
  FREE_TEXT:   { id: 'FREE_TEXT',   label: 'Прочее',        icon: 'sticky_note_2',    color: 'surface'  },
};

// Color role → CSS background/foreground for the leading chip
function chipColors(role) {
  switch (role) {
    case 'primary':   return { bg: 'var(--primary)',           fg: 'var(--on-primary)' };
    case 'secondary': return { bg: 'var(--secondary)',         fg: 'var(--on-secondary)' };
    case 'tertiary':  return { bg: 'var(--tertiary)',          fg: 'var(--on-tertiary)' };
    case 'error':     return { bg: 'var(--error-container)',   fg: 'var(--on-error-container)', stroke: 'var(--error)' };
    case 'error-bold':return { bg: 'var(--error)',             fg: 'var(--on-error)' };
    case 'outline':   return { bg: 'var(--surface)',           fg: 'var(--on-surface-variant)', stroke: 'var(--outline-variant)' };
    case 'surface':   return { bg: 'var(--surface-variant)',   fg: 'var(--on-surface-variant)' };
    default:          return { bg: 'var(--surface-variant)',   fg: 'var(--on-surface-variant)' };
  }
}

// Realistic Vyborg → St. Petersburg hitchhiking race log
// timestamps are ISO with local time (no TZ issues for display)
const SAMPLE_RECORDS = [
  // Day 1 — Saturday, 16 May
  { id: 1,  type: 'START',       time: '2026-05-16T09:00', text: 'Выборг, Замковый остров. Стартовали по сигналу судьи.' },
  { id: 2,  type: 'WALK',        time: '2026-05-16T09:02', text: 'Выход к трассе А-181 «Скандинавия»' },
  { id: 3,  type: 'WALK_END',    time: '2026-05-16T09:24', text: '' },
  { id: 4,  type: 'LIFT',        time: '2026-05-16T09:31', text: 'Volvo XC60, Михаил, едет до Зеленогорска' },
  { id: 5,  type: 'GET_OFF',     time: '2026-05-16T10:48', text: 'Развязка у Зеленогорска' },
  { id: 6,  type: 'MEET',        time: '2026-05-16T10:55', text: 'Встретили команду «Север-2», обмен инфой по КП' },
  { id: 7,  type: 'LIFT',        time: '2026-05-16T11:12', text: 'Газель, водитель Андрей — везёт стройматериалы в Сестрорецк' },
  { id: 8,  type: 'CHECKPOINT',  time: '2026-05-16T12:05', text: 'КП-1 Сестрорецк. Отметились у судьи Иванова. Время в норме.' },
  { id: 9,  type: 'GET_OFF',     time: '2026-05-16T12:18', text: '' },
  { id: 10, type: 'REST_ON',     time: '2026-05-16T12:20', text: 'Обед на заправке, 30 минут' },
  { id: 11, type: 'REST_OFF',    time: '2026-05-16T12:54', text: '' },
  { id: 12, type: 'LIFT',        time: '2026-05-16T13:10', text: 'Skoda Octavia, семейная пара, едут в город' },
  { id: 13, type: 'OFFSIDE_ON',  time: '2026-05-16T14:02', text: 'Заехали к родственникам водителя — крюк ~15 мин' },
  { id: 14, type: 'OFFSIDE_OFF', time: '2026-05-16T14:21', text: 'Снова на трассе' },
  { id: 15, type: 'GET_OFF',     time: '2026-05-16T15:08', text: 'Удельная, развязка КАД' },
  { id: 16, type: 'CHECKPOINT',  time: '2026-05-16T15:42', text: 'КП-2 ст. Удельная. Отметка в зачёт.' },
  { id: 17, type: 'FREE_TEXT',   time: '2026-05-16T16:00', text: 'Сильный встречный ветер, машины идут плотно но почти не останавливаются. Пробуем точку у съезда.' },

  // Day 2 — Sunday, 17 May
  { id: 18, type: 'WALK',        time: '2026-05-17T07:30', text: 'Утренний выход с ночёвки в Парголово' },
  { id: 19, type: 'WALK_END',    time: '2026-05-17T07:55', text: '' },
  { id: 20, type: 'LIFT',        time: '2026-05-17T08:10', text: 'KamAZ, дальнобой Виктор, идёт до порта' },
  { id: 21, type: 'GET_OFF',     time: '2026-05-17T08:48', text: 'Развязка ЗСД' },
  { id: 22, type: 'CHECKPOINT',  time: '2026-05-17T09:12', text: 'КП-3 Лахта. Контрольный звонок штабу принят.' },
  { id: 23, type: 'LIFT',        time: '2026-05-17T09:30', text: 'BMW 3, Дмитрий, до Васильевского' },
  { id: 24, type: 'GET_OFF',     time: '2026-05-17T10:06', text: '' },
  { id: 25, type: 'WALK',        time: '2026-05-17T10:08', text: 'Через мост на Петроградку' },
  { id: 26, type: 'WALK_END',    time: '2026-05-17T10:34', text: '' },
  { id: 27, type: 'FINISH',      time: '2026-05-17T10:47', text: 'Дворцовая площадь. Финиш засвидетельствовал судья Петров. Итоговое время 25:47.' },
];

// Format helpers
const MONTHS_RU = ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
const WEEKDAYS_RU = ['воскресенье','понедельник','вторник','среда','четверг','пятница','суббота'];

function formatDateHeader(iso) {
  const d = new Date(iso);
  const today = new Date(); today.setHours(0,0,0,0);
  const dd = new Date(d); dd.setHours(0,0,0,0);
  const diffDays = Math.round((dd - today) / 86400000);
  let prefix = '';
  if (diffDays === 0) prefix = 'Сегодня · ';
  else if (diffDays === -1) prefix = 'Вчера · ';
  return `${prefix}${d.getDate()} ${MONTHS_RU[d.getMonth()]} ${d.getFullYear()}, ${WEEKDAYS_RU[d.getDay()]}`;
}
function formatTime(iso) {
  const d = new Date(iso);
  return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
}
function dateKey(iso) { return iso.slice(0, 10); }

Object.assign(window, {
  RECORD_TYPES, SAMPLE_RECORDS, chipColors,
  formatDateHeader, formatTime, dateKey,
});
