// record-edit-screen.jsx — Создание / редактирование записи
// Two visual variants of fields (M3 OutlinedTextField vs large tap-targets)
// Common fields: дата, время, текст. Type is fixed (chip header, read-only).

const { useState: useS2, useRef: useR2, useEffect: useE2 } = React;

// ---- Top app bar (close-left, title-center, action-trailing) ----
function EditTopAppBar({ title, onClose, onDelete, onSave }) {
  return (
    <div style={{
      height: 64, display: 'flex', alignItems: 'center',
      padding: '0 4px',
      background: 'var(--surface)',
      borderBottom: '1px solid var(--outline-variant)',
      flexShrink: 0,
    }}>
      <IconButton icon="close" onClick={onClose} />
      <div style={{
        flex: 1, padding: '0 8px',
        fontSize: 22, fontWeight: 500, lineHeight: '28px',
        color: 'var(--on-surface)', letterSpacing: 0,
      }}>{title}</div>
      {onDelete && <IconButton icon="delete" onClick={onDelete} color="var(--error)" />}
      <button
        onClick={onSave}
        style={{
          height: 40, padding: '0 16px', marginLeft: 4, marginRight: 8,
          background: 'transparent', color: 'var(--primary)',
          border: 'none', borderRadius: 20, cursor: 'pointer',
          fontFamily: 'Roboto', fontSize: 14, fontWeight: 500, letterSpacing: 0.1,
          textTransform: 'uppercase',
        }}
      >Сохранить</button>
    </div>
  );
}

// ---- Type-display chip (read-only — type is fixed) ----
function TypeDisplay({ type }) {
  const def = RECORD_TYPES[type];
  if (!def) return null;
  const c = chipColors(def);
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 10,
      padding: '6px 14px 6px 6px', borderRadius: 100,
      background: 'var(--surface-variant)', color: 'var(--on-surface-variant)',
      fontSize: 13, fontWeight: 500,
    }}>
      <span style={{
        width: 28, height: 28, borderRadius: '50%',
        background: c.bg, color: c.fg,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        border: c.stroke ? `1px solid ${c.stroke}` : 'none',
      }}>
        <span className="material-symbols-outlined" style={{ fontSize: 18, color: c.fg }}>{def.icon}</span>
      </span>
      <span>{def.label}</span>
    </div>
  );
}

// =================================================================
// Variant A — M3 Outlined Text Fields
// =================================================================

function OutlinedField({ label, value, onChange, type = 'text', leadingIcon, supporting, autoFocus, multiline, rows = 4 }) {
  const [focused, setFocused] = useS2(false);
  const inputRef = useR2(null);
  const filled = value != null && value !== '';
  const floating = focused || filled;

  const borderColor = focused ? 'var(--primary)' : 'var(--outline)';
  const borderWidth = focused ? 2 : 1;

  // Notch geometry — must include leading icon offset if present
  const labelOffsetX = leadingIcon ? 36 : 12;

  useE2(() => {
    if (autoFocus && inputRef.current) inputRef.current.focus();
  }, [autoFocus]);

  const inputProps = {
    ref: inputRef,
    value: value || '',
    onChange: e => onChange(e.target.value),
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    style: {
      width: '100%', height: multiline ? 'auto' : 56,
      padding: multiline ? '16px 16px' : `${leadingIcon ? '0 16px 0 44px' : '0 16px'}`,
      paddingTop: multiline ? 16 : 0,
      border: 'none', outline: 'none', background: 'transparent',
      fontFamily: 'Roboto', fontSize: 16, fontWeight: 400, lineHeight: '24px', letterSpacing: 0.5,
      color: 'var(--on-surface)', resize: multiline ? 'vertical' : 'none',
    },
    placeholder: floating ? '' : '',
  };

  return (
    <div style={{ position: 'relative', marginBottom: 4 }}>
      <div
        onClick={() => inputRef.current && inputRef.current.focus()}
        style={{
          position: 'relative',
          minHeight: multiline ? 'auto' : 56,
          border: `${borderWidth}px solid ${borderColor}`,
          borderRadius: 4,
          background: 'transparent',
          transition: 'border-color 120ms',
          cursor: 'text',
          paddingLeft: leadingIcon && !multiline ? 0 : 0,
        }}
      >
        {leadingIcon && !multiline && (
          <span className="material-symbols-outlined" style={{
            position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)',
            fontSize: 24, color: 'var(--on-surface-variant)', pointerEvents: 'none',
          }}>{leadingIcon}</span>
        )}

        {/* Floating label with notch effect */}
        <div style={{
          position: 'absolute',
          left: labelOffsetX - 4, top: floating ? -8 : 16,
          padding: floating ? '0 4px' : 0,
          background: floating ? 'var(--background)' : 'transparent',
          fontFamily: 'Roboto',
          fontSize: floating ? 12 : 16,
          fontWeight: 400, letterSpacing: 0.4,
          color: focused ? 'var(--primary)' : 'var(--on-surface-variant)',
          transition: 'all 120ms',
          pointerEvents: 'none',
          lineHeight: floating ? '16px' : '24px',
        }}>{label}</div>

        {multiline
          ? <textarea {...inputProps} rows={rows} />
          : <input {...inputProps} type={type} />}
      </div>
      {supporting && (
        <div style={{
          fontSize: 12, color: 'var(--on-surface-variant)',
          padding: '4px 16px 0', letterSpacing: 0.4,
        }}>{supporting}</div>
      )}
    </div>
  );
}

// =================================================================
// Variant B — Large tap-target rows ("inline" fields)
// =================================================================

function BigFieldRow({ icon, label, value, onClick, multiline, placeholder }) {
  const [pressed, setPressed] = useS2(false);
  return (
    <div
      onClick={onClick}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        display: 'flex', alignItems: multiline ? 'flex-start' : 'center', gap: 16,
        minHeight: multiline ? 100 : 72, padding: multiline ? '20px 20px' : '0 20px',
        cursor: onClick ? 'pointer' : 'default',
        background: pressed ? 'var(--surface-container)' : 'var(--surface)',
        borderBottom: '1px solid var(--outline-variant)',
        transition: 'background 80ms',
      }}
    >
      {icon && (
        <span className="material-symbols-outlined" style={{
          fontSize: 24, color: 'var(--on-surface-variant)',
          marginTop: multiline ? 2 : 0,
          flexShrink: 0,
        }}>{icon}</span>
      )}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 12, fontWeight: 500, letterSpacing: 0.4,
          color: 'var(--on-surface-variant)', textTransform: 'uppercase',
        }}>{label}</div>
        <div style={{
          marginTop: 4,
          fontSize: 18, fontWeight: 400, lineHeight: '24px',
          color: value ? 'var(--on-surface)' : 'var(--on-surface-variant)',
          whiteSpace: multiline ? 'pre-wrap' : 'nowrap',
          overflow: multiline ? 'visible' : 'hidden',
          textOverflow: multiline ? 'clip' : 'ellipsis',
          opacity: value ? 1 : 0.6,
        }}>{value || placeholder}</div>
      </div>
      {onClick && !multiline && (
        <span className="material-symbols-outlined" style={{
          fontSize: 22, color: 'var(--on-surface-variant)', opacity: 0.6, flexShrink: 0,
        }}>chevron_right</span>
      )}
    </div>
  );
}

function BigTextArea({ icon, label, value, onChange, placeholder, autoFocus }) {
  const ref = useR2(null);
  useE2(() => {
    if (autoFocus && ref.current) ref.current.focus();
  }, [autoFocus]);
  return (
    <div style={{
      display: 'flex', alignItems: 'flex-start', gap: 16,
      padding: '20px',
      background: 'var(--surface)',
      borderBottom: '1px solid var(--outline-variant)',
      minHeight: 160,
    }}>
      {icon && (
        <span className="material-symbols-outlined" style={{
          fontSize: 24, color: 'var(--on-surface-variant)', marginTop: 2, flexShrink: 0,
        }}>{icon}</span>
      )}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 12, fontWeight: 500, letterSpacing: 0.4,
          color: 'var(--on-surface-variant)', textTransform: 'uppercase',
        }}>{label}</div>
        <textarea
          ref={ref}
          value={value || ''}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          rows={5}
          style={{
            marginTop: 6,
            width: '100%', border: 'none', outline: 'none', background: 'transparent',
            fontFamily: 'Roboto', fontSize: 18, fontWeight: 400, lineHeight: '26px',
            color: 'var(--on-surface)', resize: 'none',
            minHeight: 110,
          }}
        />
      </div>
    </div>
  );
}

// =================================================================
// Main screen
// =================================================================

function RecordEditScreen({ mode = 'new', type, initial, fieldStyle = 'outlined', onClose, onSave, onDelete }) {
  const def = RECORD_TYPES[type] || {};

  // Defaults — for "new", set to current time (the static-mocked one); for "edit", use initial
  const [date, setDate] = useS2(initial?.date || '2026-05-16');
  const [time, setTime] = useS2(initial?.time || '09:31');
  const [text, setText] = useS2(initial?.text || '');

  const isEdit = mode === 'edit';
  const title = isEdit ? def.label || 'Запись' : 'Новая запись';

  return (
    <div style={{
      flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column',
      background: 'var(--background)', overflow: 'hidden',
    }}>
      <EditTopAppBar
        title={title}
        onClose={onClose}
        onDelete={isEdit ? onDelete : null}
        onSave={() => onSave && onSave({ type, date, time, text })}
      />

      {/* Type chip header — type is fixed, shown read-only */}
      <div style={{
        padding: '16px 20px 4px',
        display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0,
      }}>
        <span style={{ fontSize: 12, fontWeight: 500, letterSpacing: 0.4,
          color: 'var(--on-surface-variant)', textTransform: 'uppercase' }}>Тип</span>
        <TypeDisplay type={type} />
      </div>

      {/* Body — fields stack */}
      <div style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden' }}>
        {fieldStyle === 'outlined' ? (
          <div style={{ padding: '16px 20px 24px', display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div style={{ display: 'flex', gap: 12 }}>
              <div style={{ flex: 1 }}>
                <OutlinedField
                  label="Дата"
                  value={date}
                  onChange={setDate}
                  type="date"
                  leadingIcon="calendar_month"
                />
              </div>
              <div style={{ flex: 1 }}>
                <OutlinedField
                  label="Время"
                  value={time}
                  onChange={setTime}
                  type="time"
                  leadingIcon="schedule"
                />
              </div>
            </div>
            <OutlinedField
              label={textLabelFor(type)}
              value={text}
              onChange={setText}
              multiline
              rows={5}
              autoFocus={!isEdit}
            />
          </div>
        ) : (
          <div style={{ padding: '8px 0 24px', display: 'flex', flexDirection: 'column' }}>
            <BigFieldRow
              icon="calendar_month"
              label="Дата"
              value={formatDateForDisplay(date)}
              onClick={() => {}}
            />
            <BigFieldRow
              icon="schedule"
              label="Время"
              value={time}
              onClick={() => {}}
            />
            <BigTextArea
              icon="notes"
              label={textLabelFor(type)}
              value={text}
              onChange={setText}
              placeholder={textPlaceholderFor(type)}
              autoFocus={!isEdit}
            />
          </div>
        )}
      </div>
    </div>
  );
}

// Context-aware text label (per design system)
function textLabelFor(type) {
  switch (type) {
    case 'LIFT':       return 'Марка автомобиля';
    case 'CHECKPOINT': return 'Номер КП и информация';
    case 'MEET':       return 'Участник';
    default:           return 'Заметка (необязательно)';
  }
}
function textPlaceholderFor(type) {
  switch (type) {
    case 'LIFT':       return 'Например: Volvo XC60, Михаил, до Зеленогорска';
    case 'CHECKPOINT': return 'Например: КП-1 Сестрорецк, судья Иванов';
    case 'MEET':       return 'Команда / имя';
    default:           return 'Дополнительные детали';
  }
}

function formatDateForDisplay(iso) {
  if (!iso) return '';
  const [y, m, d] = iso.split('-');
  if (!y) return iso;
  return `${d}.${m}.${y}`;
}

Object.assign(window, {
  RecordEditScreen, EditTopAppBar, TypeDisplay,
  OutlinedField, BigFieldRow, BigTextArea,
});
