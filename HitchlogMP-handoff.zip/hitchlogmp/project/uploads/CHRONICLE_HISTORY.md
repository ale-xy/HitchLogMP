# История правок хроники — дизайн-документ

## Итоги обсуждения

| Тема | Решение |
|---|---|
| Что фиксируется | Создание (v1), изменение времени/текста/типа, удаление |
| Время правки | `editedAt` — клиентский `Clock.System.now()`, не серверный timestamp |
| Удаление | Soft delete: флаг `deleted: true`, запись остаётся в БД |
| Хранение истории | Подколлекция `records/{recordId}/history` |
| Откат | Не нужен — история только для просмотра |
| Старые записи | Нет подколлекции `history` — нормально, миграция не требуется |
| Офлайн | Firestore SDK буферизует офлайн; `editedAt` в подколлекции `history` пишется клиентом в момент действия |
| UI — основной список | Удалённые записи не показываются |
| UI — история лога | Отдельный экран со всеми правками по всем записям |
| UI — история записи | Кнопка «История» в EditRecordScreen, видна если `edited = true` |
| UI — дифф | Зачёркнутое старое значение рядом с новым |
| Экспорт | HTML и XLSX: активные записи + раздел «Исправления» в конце |

---

## 1. Структура БД

### 1.1 Новые поля в документе записи (`logs/{logId}/records/{recordId}`)

```
deleted:    Boolean    // отсутствует или false = активна; true = soft delete
edited: Boolean    // отсутствует или false = нет правок; true = есть подколлекция history
```

- При **создании**: `edited` не выставляется, `deleted` не выставляется.
- При **редактировании**: снапшот текущего состояния пишется в `history`, затем обновляется основной документ + `edited = true`.
- При **удалении**: `deleted = true`, `edited = true`, снапшот с `changeType = DELETE` пишется в `history`. Физически документ не удаляется.

**Почему не `editedAt` в основном документе:** он был бы нужен только чтобы показать/скрыть кнопку «История», но `edited: Boolean` решает эту задачу проще и дешевле. Само время правки хранится в каждом документе подколлекции `history` и там оно точнее — видно время каждой конкретной правки, а не только последней.

### 1.2 Подколлекция истории (`records/{recordId}/history/{historyId}`)

Каждый документ — полный снапшот состояния записи **до** изменения + метаданные правки.

```
historyId:  String      // UUID, генерируется клиентом
editedAt:   Timestamp   // когда сделана правка (клиентский now())
changeType: String      // UPDATE | DELETE
// Снапшот полей записи на момент ДО правки:
time:       Timestamp
type:       String      // HitchLogRecordType
text:       String
```

**Почему снапшот «до», а не «после»:** текущее состояние всегда доступно в основном документе. Арбитру важно видеть, что именно было изменено — т.е. что было раньше.

**При создании** запись в `history` не пишется — исходное содержимое доступно в основном документе, `edited` остаётся `false`.

### 1.3 Итоговая структура Firestore

```
logs/{logId}
└── records/{recordId}
    │   time:       Timestamp
    │   type:       String
    │   text:       String
    │   deleted:    Boolean       ← новое поле
    │   edited: Boolean       ← новое поле
    └── history/                  ← новая подколлекция
        └── {historyId}
                historyId:  String
                editedAt:   Timestamp
                changeType: String   // UPDATE | DELETE
                time:       Timestamp
                type:       String
                text:       String
```

---

## 2. Изменения в доменной модели

### 2.1 Новый класс `HitchLogRecordHistoryEntry`

```kotlin
data class HitchLogRecordHistoryEntry(
    val historyId: String,          // UUID
    val editedAt: Instant,          // клиентский Clock.System.now()
    val changeType: ChangeType,
    // снапшот полей записи до правки:
    val time: LocalDateTime,
    val type: HitchLogRecordType,
    val text: String
)

enum class ChangeType { UPDATE, DELETE }
```

### 2.2 Изменения в `HitchLogRecord`

```kotlin
data class HitchLogRecord(
    val id: String,
    val time: LocalDateTime,
    val type: HitchLogRecordType,
    val text: String,
    val deleted: Boolean = false,     // ← новое
    val edited: Boolean = false   // ← новое; false для старых записей
)
```

---

## 3. Изменения в Repository

### 3.1 Новые методы в интерфейсе `Repository`

```kotlin
// Получить историю конкретной записи
fun getRecordHistory(
    logId: String,
    recordId: String
): Flow<Response<List<HitchLogRecordHistoryEntry>>>

// Получить полную историю всех записей лога (для экрана истории лога)
fun getLogHistory(
    logId: String
): Flow<Response<List<Pair<String, HitchLogRecordHistoryEntry>>>>
// Pair<recordId, entry>
```

### 3.2 Изменения в `saveRecord` и `deleteRecord`

**`saveRecord` (создание и редактирование):**
```kotlin
// Псевдокод логики в FirestoreRepository
suspend fun saveRecord(logId: String, record: HitchLogRecord) {
    val now = Clock.System.now()

    if (record.id.isEmpty()) {
        // Создание: просто пишем запись, history не трогаем
        val newRecord = record.copy(id = UUID.randomUUID().toString())
        firestore.collection("logs/$logId/records").document(newRecord.id).set(newRecord)
    } else {
        // Редактирование: читаем текущую версию → пишем в history → обновляем документ
        val current = firestore.getRecord(logId, record.id)
        writeHistory(logId, record.id, ChangeType.UPDATE, current, now)
        firestore.document("logs/$logId/records/${record.id}")
            .set(record.copy(edited = true))
    }
}

// Удаление — только soft delete
suspend fun deleteRecord(logId: String, record: HitchLogRecord) {
    val now = Clock.System.now()
    writeHistory(logId, record.id, ChangeType.DELETE, record, now)
    firestore.document("logs/$logId/records/${record.id}")
        .update(mapOf("deleted" to true, "edited" to true))
}

private suspend fun writeHistory(
    logId: String,
    recordId: String,
    changeType: ChangeType,
    snapshot: HitchLogRecord,
    editedAt: Instant
) {
    val entry = HitchLogRecordHistoryEntry(
        historyId = UUID.randomUUID().toString(),
        editedAt = editedAt,   // клиентский Clock.System.now() — фиксирует момент действия, не синхронизации
        changeType = changeType,
        time = snapshot.time,
        type = snapshot.type,
        text = snapshot.text
    )
    firestore.collection("logs/$logId/records/$recordId/history")
        .document(entry.historyId).set(entry)
}
```

### 3.3 Фильтрация удалённых записей

`getLogRecords` фильтрует на клиенте при маппинге:

```kotlin
records.filter { !it.deleted }
```

Записей в одном логе немного, поэтому клиентская фильтрация достаточна. Серверный `.whereNotEqualTo("deleted", true)` потребовал бы составного индекса и усложнил запрос без реальной выгоды. Старые записи без поля `deleted` читаются с дефолтом `false` и корректно проходят фильтр.

---

## 4. UI

### 4.1 Новый экран: `RecordHistoryScreen`

Маршрут: `Screen.RecordHistory(logId: String, recordId: String)`

Отображает список версий записи в обратном хронологическом порядке (свежие сверху). Каждый элемент:

- Время правки (`editedAt`) — реальное время устройства
- Тип: «Создана» / «Изменена» / «Удалена»
- Дифф по изменившимся полям: ~~старое~~ → новое

**Логика диффа на клиенте:** сортируем `history` по `editedAt` возрастанию. Для каждой записи «новое» значение = следующий снапшот (или текущий основной документ для последней правки). Показываем только поля, которые изменились.

Пример отображения:
```
14:23, 12 июл  •  Изменена
  Время:   ~~13:45~~ → 13:50
  Текст:   ~~Газель у поста~~ → Газель у поста ДПС

09:11, 12 июл  •  Создана
  Время:   13:45
  Тип:     LIFT
  Текст:   Газель у поста
```

### 4.2 Изменения в `EditRecordScreen`

Добавить кнопку «История» в toolbar (иконка часов). Кнопка видна только если `record.edited == true`.

При нажатии — навигация на `Screen.RecordHistory(logId, recordId)`.

### 4.3 Новый экран: `LogHistoryScreen`

Маршрут: `Screen.LogHistory(logId: String)`

Все правки по всем записям лога, отсортированные по `editedAt` убыванию. Каждый элемент показывает тип исходной записи (LIFT, REST_ON и т.д.), тип правки и краткий дифф.

Точка входа: меню в `HitchLogScreen` («История правок»).

### 4.4 Удалённые записи

| Место | Поведение |
|---|---|
| `HitchLogScreen` (основной список) | Не показываются |
| `LogHistoryScreen` | Видны как событие «Удалена» |
| `RecordHistoryScreen` | Последний элемент — запись с `changeType = DELETE` |

---

## 5. Экспорт для арбитра

### 5.1 Структура

**Основная часть** — без изменений, только активные записи (`deleted = false`).

**Новый раздел «Исправления»** добавляется в конце, если есть хотя бы одна правка:

```
ИСПРАВЛЕНИЯ
────────────────────────────────────────────────────
12 июл 14:23  ИЗМЕНЕНА  [LIFT]
  было:  13:45 / Газель, выгрузился у поста
  стало: 13:50 / Газель, выгрузился у поста ДПС

12 июл 09:11  УДАЛЕНА  [REST_ON]
  было:  08:00 / начало отдыха

11 июл 22:05  СОЗДАНА  [START]
  21:00 / старт
```

### 5.2 Реализация по форматам

| Формат | Что делаем |
|---|---|
| **HTML** | Новая `<section id="corrections">` после основной таблицы. Зачёркивание через `<s>`. |
| **XLSX** | Новый лист «Исправления». Зачёркивание через стиль ячейки. |
| **TXT** | Решить отдельно — скорее всего простой текстовый блок в конце файла. |
| **CSV** | Решить отдельно — возможно, отдельный файл `_history.csv`. |

---

## 6. Миграция

Никакой серверной миграции не требуется.

- Старые записи без `history` — приложение читает отсутствие подколлекции как «нет правок».
- Отсутствие полей `deleted` / `edited` — читаются с дефолтами (`false` / `false`).
- `edited = false` → кнопка «История» в `EditRecordScreen` скрыта.

---

## 7. Новые навигационные маршруты

```kotlin
// В Nav.kt:
data class RecordHistory(val logId: String, val recordId: String) : Screen
data class LogHistory(val logId: String) : Screen

// В HitchLogApp.kt:
composable<Screen.RecordHistory> { backStackEntry ->
    val args = backStackEntry.toRoute<Screen.RecordHistory>()
    RecordHistoryScreen(logId = args.logId, recordId = args.recordId)
}
composable<Screen.LogHistory> { backStackEntry ->
    val args = backStackEntry.toRoute<Screen.LogHistory>()
    LogHistoryScreen(logId = args.logId)
}
```

---

## 8. Новые ViewModel'ы

| ViewModel | Параметры | State |
|---|---|---|
| `RecordHistoryViewModel` | `logId`, `recordId` | `StateFlow<ViewState<List<HitchLogRecordHistoryEntry>>>` |
| `LogHistoryViewModel` | `logId` | `StateFlow<ViewState<List<Pair<String, HitchLogRecordHistoryEntry>>>>` |

Регистрация в `AppModule.kt`:
```kotlin
viewModel { params -> RecordHistoryViewModel(get(), params[0], params[1]) }
viewModel { params -> LogHistoryViewModel(get(), params[0]) }
```

---

## 9. Порядок реализации

1. **Модель** — `ChangeType`, `HitchLogRecordHistoryEntry`, новые поля в `HitchLogRecord`.
2. **Repository** — `writeHistory()`, `getRecordHistory()`, `getLogHistory()`, soft delete в `deleteRecord()`, фильтрация в `getLogRecords()`.
3. **RecordHistoryScreen** + `RecordHistoryViewModel` + кнопка «История» в `EditRecordScreen`.
4. **LogHistoryScreen** + `LogHistoryViewModel` + точка входа из `HitchLogScreen`.
5. **Экспорт** — раздел «Исправления» в HTML и XLSX.
