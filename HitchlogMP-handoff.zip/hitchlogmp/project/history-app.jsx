// history-app.jsx — host shell for History screens

const { useState: useSHA, useEffect: useEHA } = React;

const HISTORY_TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "screen": "log",
  "sortMode": "by-record",
  "recordId": 4,
  "darkMode": false
}/*EDITMODE-END*/;

function HistoryApp() {
  const [tweaks, setTweak] = useTweaks(HISTORY_TWEAK_DEFAULTS);
  const [snack, setSnack] = useSHA(null);

  // Dark mode tokens (same set used across other screens for parity)
  useEHA(() => {
    if (tweaks.darkMode) {
      document.documentElement.style.setProperty('--background', '#11131A');
      document.documentElement.style.setProperty('--on-background', '#E4E2E9');
      document.documentElement.style.setProperty('--surface', '#191C24');
      document.documentElement.style.setProperty('--on-surface', '#E4E2E9');
      document.documentElement.style.setProperty('--surface-variant', '#252835');
      document.documentElement.style.setProperty('--on-surface-variant', '#C5C6D0');
      document.documentElement.style.setProperty('--outline', '#8E909A');
      document.documentElement.style.setProperty('--outline-variant', '#363946');
      document.documentElement.style.setProperty('--surface-container-low', '#1A1D26');
      document.documentElement.style.setProperty('--surface-container', '#1F2230');
      document.documentElement.style.setProperty('--primary', '#B0C4FF');
      document.documentElement.style.setProperty('--on-primary', '#012078');
      document.documentElement.style.setProperty('--primary-container', '#002C9F');
      document.documentElement.style.setProperty('--on-primary-container', '#D9E2FF');
      document.documentElement.style.setProperty('--secondary-container', '#4E4900');
      document.documentElement.style.setProperty('--on-secondary-container', '#FFEC91');
      document.documentElement.style.setProperty('--error-container', '#640A0E');
      document.documentElement.style.setProperty('--on-error-container', '#FFDAD6');
    } else {
      ['background','on-background','surface','on-surface','surface-variant','on-surface-variant','outline','outline-variant','surface-container-low','surface-container','primary','on-primary','primary-container','on-primary-container','secondary-container','on-secondary-container','error-container','on-error-container']
        .forEach(k => document.documentElement.style.removeProperty('--' + k));
    }
  }, [tweaks.darkMode]);

  const logName = 'Выборг — Петербург';

  // Pick a record that actually has history
  const recordIdsWithHistory = recordIdsByCreation();
  const activeRecordId = recordIdsWithHistory.includes(tweaks.recordId)
    ? tweaks.recordId
    : recordIdsWithHistory[0];

  return (
    <>
      <PhoneFrame>
        {tweaks.screen === 'log' ? (
          <LogHistoryScreen
            logName={logName}
            sortMode={tweaks.sortMode}
            onChangeMode={(v) => setTweak('sortMode', v)}
            onBack={() => setSnack('← К хронике')}
            onPickEvent={(ev) => setSnack(`Правка ${changeTypeLabel(ev.changeType)} · ${formatHistoryTime(ev.editedAt)}`)}
            onOpenRecord={(rid) => setTweak({ screen: 'record', recordId: rid })}
          />
        ) : (
          <RecordHistoryScreen
            recordId={activeRecordId}
            onBack={() => setTweak('screen', 'log')}
          />
        )}
        {snack && <HistSnackbar message={snack} onDismiss={() => setSnack(null)} />}
      </PhoneFrame>

      <TweaksPanel>
        <TweakSection label="Экран" />
        <TweakRadio
          label="Что показать"
          value={tweaks.screen}
          onChange={v => setTweak('screen', v)}
          options={[
            { value: 'log',    label: 'История лога' },
            { value: 'record', label: 'История записи' },
          ]}
        />

        {tweaks.screen === 'log' && (
          <>
            <TweakSection label="Режим сортировки" />
            <TweakRadio
              label="Порядок"
              value={tweaks.sortMode}
              onChange={v => setTweak('sortMode', v)}
              options={[
                { value: 'by-time',   label: 'По времени' },
                { value: 'by-record', label: 'По записям' },
              ]}
            />
          </>
        )}

        {tweaks.screen === 'record' && (
          <>
            <TweakSection label="Запись" />
            <TweakSelect
              label="Какая запись"
              value={activeRecordId}
              onChange={v => setTweak('recordId', Number(v))}
              options={recordIdsWithHistory.map(rid => {
                const live = currentSnapshot(rid);
                const def = RECORD_TYPES[live?.type] || {};
                const suffix = live?.deleted ? ' (удалена)' : '';
                return { value: rid, label: `#${rid} ${def.label || ''}${suffix}` };
              })}
            />
          </>
        )}

        <TweakSection label="Тема" />
        <TweakToggle
          label="Тёмная тема"
          value={tweaks.darkMode}
          onChange={v => setTweak('darkMode', v)}
        />
      </TweaksPanel>
    </>
  );
}

function HistSnackbar({ message, onDismiss }) {
  useEHA(() => {
    const t = setTimeout(onDismiss, 2400);
    return () => clearTimeout(t);
  }, [message, onDismiss]);
  return (
    <div style={{
      position: 'absolute', left: 16, right: 16, bottom: 32,
      background: '#322F35', color: '#F4EFF4',
      padding: '14px 16px', borderRadius: 4,
      fontSize: 14, lineHeight: '20px',
      boxShadow: '0 6px 12px rgba(0,0,0,0.2)',
      zIndex: 80,
    }}>{message}</div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<HistoryApp />);
