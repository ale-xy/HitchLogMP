// record-edit-app.jsx — host shell for RecordEditScreen
// Provides PhoneFrame, snackbar, tweaks (mode / type / fieldStyle / dark)

const { useState: useS3, useEffect: useE3 } = React;

// PhoneFrame is provided by hitchlog-frame.jsx (shared)

// Sample initial values for edit mode (corresponds to a record in the chronicle)
const SAMPLE_EDIT_INITIAL = {
  LIFT:       { date: '2026-05-16', time: '11:12', text: 'Газель, водитель Андрей — везёт стройматериалы в Сестрорецк' },
  CHECKPOINT: { date: '2026-05-16', time: '12:05', text: 'КП-1 Сестрорецк. Отметились у судьи Иванова. Время в норме.' },
  MEET:       { date: '2026-05-16', time: '10:55', text: 'Встретили команду «Север-2», обмен инфой по КП' },
  REST_ON:    { date: '2026-05-16', time: '12:20', text: 'Обед на заправке, 30 минут' },
  OFFSIDE_ON: { date: '2026-05-16', time: '14:02', text: 'Заехали к родственникам водителя — крюк ~15 мин' },
  WALK:       { date: '2026-05-16', time: '09:02', text: 'Выход к трассе А-181 «Скандинавия»' },
  START:      { date: '2026-05-16', time: '08:45', text: 'Старт от штаба у Финляндского вокзала' },
  CHECKPOINT_DEFAULT: null,
};

// Tweak defaults — host can rewrite this block on disk
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "mode": "new",
  "type": "LIFT",
  "fieldStyle": "outlined",
  "darkMode": false
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [snack, setSnack] = useS3(null);

  useE3(() => {
    setRecordPaletteTheme(tweaks.darkMode);
    if (tweaks.darkMode) {
      document.documentElement.style.setProperty('--background', '#11131A');
      document.documentElement.style.setProperty('--on-background', '#E4E2E9');
      document.documentElement.style.setProperty('--surface', '#191C24');
      document.documentElement.style.setProperty('--on-surface', '#E4E2E9');
      document.documentElement.style.setProperty('--surface-variant', '#2C2F37');
      document.documentElement.style.setProperty('--on-surface-variant', '#C5C6D0');
      document.documentElement.style.setProperty('--surface-container-low', '#1B1E26');
      document.documentElement.style.setProperty('--surface-container', '#22252D');
      document.documentElement.style.setProperty('--outline', '#8E8F99');
      document.documentElement.style.setProperty('--outline-variant', '#44464F');
      document.documentElement.style.setProperty('--primary', '#B4C5FF');
      document.documentElement.style.setProperty('--on-primary', '#002780');
      document.documentElement.style.setProperty('--primary-container', '#003BB4');
      document.documentElement.style.setProperty('--on-primary-container', '#DBE1FF');
    } else {
      ['background','on-background','surface','on-surface','surface-variant','on-surface-variant',
       'surface-container-low','surface-container','outline','outline-variant',
       'primary','on-primary','primary-container','on-primary-container']
        .forEach(k => document.documentElement.style.removeProperty('--' + k));
    }
  }, [tweaks.darkMode]);

  // Pick initial values: edit mode uses SAMPLE map; new gets empty (defaults inside screen)
  const initial = tweaks.mode === 'edit'
    ? (SAMPLE_EDIT_INITIAL[tweaks.type] || { date: '2026-05-16', time: '12:00', text: '' })
    : null;

  const handleSave = (data) => {
    setSnack(`Сохранено: ${RECORD_TYPES[data.type]?.label} в ${data.time}`);
  };
  const handleDelete = () => {
    setSnack('Запись удалена');
  };
  const handleClose = () => {
    setSnack('Закрыто без сохранения');
  };

  // All record types — for the type tweak
  const typeOptions = [
    'START','LIFT','GET_OFF','WALK','WALK_END','CHECKPOINT',
    'MEET','REST_ON','REST_OFF','OFFSIDE_ON','OFFSIDE_OFF',
    'FINISH','RETIRE','FREE_TEXT'
  ].map(t => ({ value: t, label: RECORD_TYPES[t].label }));

  return (
    <>
      <PhoneFrame>
        <RecordEditScreen
          key={`${tweaks.mode}-${tweaks.type}-${tweaks.fieldStyle}`}
          mode={tweaks.mode}
          type={tweaks.type}
          initial={initial}
          fieldStyle={tweaks.fieldStyle}
          onClose={handleClose}
          onSave={handleSave}
          onDelete={handleDelete}
        />
        {snack && <Snackbar message={snack} onDismiss={() => setSnack(null)} />}
      </PhoneFrame>

      <TweaksPanel>
        <TweakSection label="Состояние" />
        <TweakRadio
          label="Режим"
          value={tweaks.mode}
          onChange={v => setTweak('mode', v)}
          options={[
            { value: 'new',  label: 'Новая' },
            { value: 'edit', label: 'Редактирование' },
          ]}
        />
        <TweakSelect
          label="Тип записи"
          value={tweaks.type}
          onChange={v => setTweak('type', v)}
          options={typeOptions}
        />

        <TweakSection label="Стиль полей" />
        <TweakRadio
          label="Вариант"
          value={tweaks.fieldStyle}
          onChange={v => setTweak('fieldStyle', v)}
          options={[
            { value: 'outlined', label: 'M3 Outlined' },
            { value: 'big',      label: 'Большие'    },
          ]}
        />

        <TweakSection label="Тема" />
        <TweakToggle
          label="Тёмная тема"
          value={tweaks.darkMode}
          onChange={v => setTweak('darkMode', v)}
        />
      </TweaksPanel>
    </>
  );
}

// Snackbar — same simple impl as in hitchlog-app
function Snackbar({ message, onDismiss }) {
  useE3(() => {
    const t = setTimeout(onDismiss, 3500);
    return () => clearTimeout(t);
  }, [message, onDismiss]);
  return (
    <div style={{
      position: 'absolute', left: 16, right: 16, bottom: 24,
      background: 'var(--on-surface)', color: 'var(--surface)',
      borderRadius: 4, padding: '14px 16px',
      fontFamily: 'Roboto', fontSize: 14, fontWeight: 400,
      boxShadow: '0 6px 20px rgba(0,0,0,0.25)',
      zIndex: 100,
    }}>{message}</div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
