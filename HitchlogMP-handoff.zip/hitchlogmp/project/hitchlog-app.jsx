// hitchlog-app.jsx — root app: device frame, screen routing, tweaks, add-record sheet

const { useState: useS, useEffect: useE } = React;

// Device shell — borrows look from android_frame but custom-themed and contained
function PhoneFrame({ children, accent }) {
  return (
    <div style={{
      width: 412, height: 892, borderRadius: 44, padding: 10,
      background: '#1d1b20',
      boxShadow: '0 40px 80px rgba(0,0,0,0.45), 0 0 0 1px rgba(255,255,255,0.06) inset',
      position: 'relative', flexShrink: 0,
    }}>
      <div style={{
        width: '100%', height: '100%', borderRadius: 36, overflow: 'hidden',
        background: 'var(--background)', display: 'flex', flexDirection: 'column',
        position: 'relative',
      }}>
        <StatusBar />
        {children}
        <NavBar />
      </div>
      {/* camera punch-hole */}
      <div style={{
        position: 'absolute', left: '50%', top: 22, transform: 'translateX(-50%)',
        width: 18, height: 18, borderRadius: '50%', background: '#000', zIndex: 100,
      }} />
    </div>
  );
}

function NavBar() {
  return (
    <div style={{
      height: 24, flexShrink: 0,
      background: 'var(--background)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <div style={{ width: 108, height: 4, borderRadius: 2, background: 'var(--on-surface)', opacity: 0.4 }} />
    </div>
  );
}

// Add-record bottom sheet (Material 3 modal sheet) — shows when FAB clicked
function AddRecordSheet({ open, onClose, onPick }) {
  const types = [
    'START','LIFT','GET_OFF','WALK','WALK_END','CHECKPOINT',
    'MEET','REST_ON','REST_OFF','OFFSIDE_ON','OFFSIDE_OFF',
    'FINISH','RETIRE','FREE_TEXT'
  ];
  return (
    <>
      {/* scrim */}
      <div
        onClick={onClose}
        style={{
          position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.32)',
          opacity: open ? 1 : 0, pointerEvents: open ? 'auto' : 'none',
          transition: 'opacity 200ms', zIndex: 50,
        }}
      />
      {/* sheet */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        background: 'var(--surface-container-low)',
        borderTopLeftRadius: 28, borderTopRightRadius: 28,
        transform: open ? 'translateY(0)' : 'translateY(110%)',
        transition: 'transform 280ms cubic-bezier(0.2, 0, 0, 1)',
        zIndex: 60, padding: '12px 0 20px',
        maxHeight: '78%', overflow: 'hidden', display: 'flex', flexDirection: 'column',
      }}>
        <div style={{ width: 32, height: 4, borderRadius: 2, background: 'var(--outline-variant)', margin: '0 auto 8px' }} />
        <div style={{ padding: '8px 16px 16px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ fontSize: 16, fontWeight: 500, color: 'var(--on-surface)' }}>Новая запись</div>
          <button
            onClick={onClose}
            style={{
              width: 32, height: 32, borderRadius: '50%', border: 'none',
              background: 'transparent', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            <span className="material-symbols-outlined" style={{ fontSize: 22, color: 'var(--on-surface-variant)' }}>close</span>
          </button>
        </div>
        <div style={{
          overflowY: 'auto', padding: '0 16px 8px',
          display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8,
          alignContent: 'start',
        }}>
          {types.map(t => {
            const def = RECORD_TYPES[t];
            const c = chipColors(def);
            return <SheetTypeButton key={t} def={def} c={c} onClick={() => { onPick(t); onClose(); }} />;
          })}
        </div>
      </div>
    </>
  );
}

// Single type tile inside the AddRecordSheet grid
function SheetTypeButton({ def, c, onClick }) {
  const [pressed, setPressed] = useS(false);
  return (
    <button
      onClick={onClick}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        height: 92, padding: '10px 8px',
        background: 'var(--surface)',
        border: '1px solid var(--outline-variant)', borderRadius: 16,
        cursor: 'pointer', fontFamily: 'Roboto',
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6,
        transform: pressed ? 'scale(0.96)' : 'scale(1)',
        transition: 'transform 120ms, background 120ms',
      }}
    >
      <span style={{
        width: 40, height: 40, borderRadius: '50%', background: c.bg, color: c.fg,
        border: c.stroke ? `1px solid ${c.stroke}` : 'none',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
      }}>
        <span className="material-symbols-outlined" style={{ fontSize: 22, color: c.fg }}>{def.icon}</span>
      </span>
      <div style={{
        fontSize: 12, lineHeight: '14px', fontWeight: 500, color: 'var(--on-surface)',
        textAlign: 'center', maxWidth: '100%',
        display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden',
      }}>{def.label}</div>
    </button>
  );
}

// Snackbar — small auto-dismiss toast
function Snackbar({ message, onDismiss }) {
  useE(() => {
    if (!message) return;
    const t = setTimeout(onDismiss, 2400);
    return () => clearTimeout(t);
  }, [message, onDismiss]);
  return (
    <div style={{
      position: 'absolute', left: 16, right: 16, bottom: 92,
      background: '#322F35', color: '#F4EFF4',
      padding: '14px 16px', borderRadius: 4,
      fontSize: 14, lineHeight: '20px',
      boxShadow: '0 6px 12px rgba(0,0,0,0.2)',
      transform: message ? 'translateY(0)' : 'translateY(120%)',
      opacity: message ? 1 : 0,
      transition: 'transform 240ms, opacity 200ms',
      zIndex: 80, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
    }}>
      <span>{message || ''}</span>
      <span style={{ color: 'var(--secondary)', fontWeight: 500, fontSize: 14, letterSpacing: 0.5, textTransform: 'uppercase', cursor: 'pointer' }} onClick={onDismiss}>OK</span>
    </div>
  );
}

// Tweakable defaults — host can rewrite this block on disk
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "showSummary": true,
  "logState": "in-progress",
  "quickCollapsed": false,
  "darkMode": false
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [sheetOpen, setSheetOpen] = useS(false);
  const [snack, setSnack] = useS(null);
  const [records, setRecords] = useS(SAMPLE_RECORDS);

  // Apply dark mode tokens
  useE(() => {
    setRecordPaletteTheme(tweaks.darkMode);
    if (tweaks.darkMode) {
      document.documentElement.style.setProperty('--background', '#11131A');
      document.documentElement.style.setProperty('--on-background', '#E4E2E9');
      document.documentElement.style.setProperty('--surface', '#191C24');
      document.documentElement.style.setProperty('--on-surface', '#E4E2E9');
      document.documentElement.style.setProperty('--surface-variant', '#252835');
      document.documentElement.style.setProperty('--on-surface-variant', '#C5C6D0');
      document.documentElement.style.setProperty('--outline', '#8E909A');
      document.documentElement.style.setProperty('--outline-variant', '#363946');
      document.documentElement.style.setProperty('--surface-container-low', '#1A1D26');
      document.documentElement.style.setProperty('--surface-container', '#1F2230');
      document.documentElement.style.setProperty('--primary', '#B0C4FF');
      document.documentElement.style.setProperty('--on-primary', '#012078');
      document.documentElement.style.setProperty('--primary-container', '#002C9F');
      document.documentElement.style.setProperty('--on-primary-container', '#D9E2FF');
    } else {
      ['background','on-background','surface','on-surface','surface-variant','on-surface-variant','outline','outline-variant','surface-container-low','surface-container','primary','on-primary','primary-container','on-primary-container']
        .forEach(k => document.documentElement.style.removeProperty('--' + k));
    }
  }, [tweaks.darkMode]);

  // Determine displayed records based on logState tweak
  const displayRecords = (() => {
    if (tweaks.logState === 'empty') return [];
    if (tweaks.logState === 'in-progress') {
      return records.filter(r => r.type !== 'FINISH'
        && new Date(r.time) < new Date('2026-05-17T08:00')
      );
    }
    if (tweaks.logState === 'in-car')   return records.filter(r => r.id <= 7);
    if (tweaks.logState === 'rest')     return records.filter(r => r.id <= 10);
    if (tweaks.logState === 'offside')  return records.filter(r => r.id <= 13);
    return records;
  })();

  const log = {
    name: 'Выборг — Петербург',
    team: 'Команда «Норд»',
    meta: {
      totalCheckpoints: 5,
      restBudgetMinutes: 6 * 60,   // 6 hours of rest budget
      divisibilitiesTotal: 5,
    },
  };

  const handleAdd = (type) => {
    const def = RECORD_TYPES[type];
    setSnack(`Открываю экран новой записи: ${def.label}`);
  };

  const handleRecordClick = (rec) => {
    const def = RECORD_TYPES[rec.type];
    setSnack(`Редактировать: ${def.label} · ${formatTime(rec.time)}`);
  };

  return (
    <>
      <PhoneFrame>
        <HitchLogScreen
          records={displayRecords}
          log={log}
          isEmpty={tweaks.logState === 'empty'}
          showSummary={tweaks.showSummary && tweaks.logState !== 'empty'}
          quickCollapsed={tweaks.quickCollapsed}
          onToggleQuick={() => setTweak('quickCollapsed', !tweaks.quickCollapsed)}
          onAddRecord={() => setSheetOpen(true)}
          onRecordClick={handleRecordClick}
          onPickType={handleAdd}
        />
        <AddRecordSheet
          open={sheetOpen}
          onClose={() => setSheetOpen(false)}
          onPick={handleAdd}
        />
        <Snackbar message={snack} onDismiss={() => setSnack(null)} />
      </PhoneFrame>

      <TweaksPanel>
        <TweakSection label="Состояние" />
        <TweakRadio
          label="Хроника"
          value={tweaks.logState}
          onChange={v => setTweak('logState', v)}
          options={[
            { value: 'active',      label: 'Финиш'  },
            { value: 'in-progress', label: 'В пути' },
            { value: 'empty',       label: 'Пусто' },
          ]}
        />
        <TweakRadio
          label="Статус команды"
          value={tweaks.logState}
          onChange={v => setTweak('logState', v)}
          options={[
            { value: 'in-car',  label: 'В машине' },
            { value: 'rest',    label: 'Rest'      },
            { value: 'offside', label: 'Вне игры' },
          ]}
        />
        <TweakSection label="Внешний вид" />
        <TweakToggle
          label="Карточка-сводка"
          value={tweaks.showSummary}
          onChange={v => setTweak('showSummary', v)}
        />
        <TweakToggle
          label="Свернуть быстрые действия"
          value={tweaks.quickCollapsed}
          onChange={v => setTweak('quickCollapsed', v)}
        />
        <TweakToggle
          label="Тёмная тема"
          value={tweaks.darkMode}
          onChange={v => setTweak('darkMode', v)}
        />
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
