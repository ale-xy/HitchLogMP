// chronicles-screen.jsx — Список хроник + экран создания/редактирования хроники

const { useState: useSC, useRef: useRC, useEffect: useEC, useMemo: useMC } = React;

// ---- Sample data ----
const SAMPLE_CHRONICLES = [
  { id: 1, name: 'Выборг — Петербург', recordCount: 27, date: '16–17 мая 2026' },
  { id: 2, name: 'Москва — Казань', recordCount: 14, date: '3–4 апреля 2026' },
  { id: 3, name: 'Тренировка Ленобласть', recordCount: 8, date: '20 марта 2026' },
];

// ---- Chronicles List Screen ----

function LogListScreen({ chronicles, onOpen, onEdit, onCreate, onLogout }) {
  const [scrolled, setScrolled] = useSC(false);
  const scrollRef = useRC(null);

  useEC(() => {
    const el = scrollRef.current;
    if (!el) return;
    const fn = () => setScrolled(el.scrollTop > 4);
    el.addEventListener('scroll', fn);
    return () => el.removeEventListener('scroll', fn);
  }, []);

  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden',
      background: 'var(--background)', position: 'relative',
    }}>
      {/* Top app bar */}
      <div style={{
        flexShrink: 0,
        background: scrolled ? 'var(--surface-container)' : 'var(--surface)',
        transition: 'background 200ms',
        borderBottom: scrolled ? '1px solid var(--outline-variant)' : '1px solid transparent',
      }}>
        <div style={{ height: 64, display: 'flex', alignItems: 'center', padding: '4px 4px 4px 20px' }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{
              fontSize: 22, lineHeight: '28px', fontWeight: 500,
              color: 'var(--on-surface)',
            }}>Мои хроники</div>
          </div>
          <IconButton icon="logout" onClick={onLogout} color="var(--on-surface-variant)" />
        </div>
      </div>

      {/* List */}
      <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden' }}>
        {chronicles.length === 0 ? (
          <div style={{
            flex: 1, display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center',
            padding: '64px 24px', textAlign: 'center', minHeight: 400,
          }}>
            <span className="material-symbols-outlined" style={{ fontSize: 64, color: 'var(--outline-variant)' }}>auto_stories</span>
            <div style={{ marginTop: 16, fontSize: 16, fontWeight: 500, color: 'var(--on-surface)' }}>Нет хроник</div>

          </div>
        ) : (
          <div style={{ padding: '8px 16px 120px' }}>
            {chronicles.map((c, i) => (
              <ChronicleCard
                key={c.id}
                chronicle={c}
                onOpen={() => onOpen(c)}
                onEdit={() => onEdit(c)}
                isLast={i === chronicles.length - 1}
              />
            ))}
          </div>
        )}
      </div>

      {/* FAB */}
      <button
        onClick={onCreate}
        style={{
          position: 'absolute', right: 16, bottom: 24,
          width: 56, height: 56,
          background: 'var(--primary)', color: 'var(--on-primary)',
          border: 'none', borderRadius: 16, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 4px 8px rgba(0,0,0,0.15), 0 1px 3px rgba(0,0,0,0.1)',
          zIndex: 10,
        }}
      >
        <span className="material-symbols-outlined" style={{ fontSize: 24 }}>add</span>
      </button>
    </div>
  );
}

function ChronicleCard({ chronicle, onOpen, onEdit, isLast }) {
  const [pressed, setPressed] = useSC(false);
  return (
    <div
      onClick={onOpen}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        display: 'flex', alignItems: 'center', gap: 16,
        padding: '16px',
        background: pressed ? 'var(--surface-container)' : 'var(--surface)',
        cursor: 'pointer',
        borderRadius: 12,
        border: '1px solid var(--outline-variant)',
        marginBottom: isLast ? 0 : 8,
        transition: 'background 80ms',
      }}
    >
      {/* Leading icon */}
      <div style={{
        width: 40, height: 40, borderRadius: '50%',
        background: 'var(--primary-container)', color: 'var(--on-primary-container)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
      }}>
        <span className="material-symbols-outlined" style={{ fontSize: 22 }}>auto_stories</span>
      </div>

      {/* Content */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 16, lineHeight: '24px', fontWeight: 500, color: 'var(--on-surface)',
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
        }}>{chronicle.name}</div>
      </div>

      {/* Edit button */}
      <button
        onClick={(e) => { e.stopPropagation(); onEdit(); }}
        style={{
          width: 40, height: 40, border: 'none', background: 'transparent',
          borderRadius: '50%', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        }}
      >
        <span className="material-symbols-outlined" style={{ fontSize: 20, color: 'var(--on-surface-variant)' }}>edit</span>
      </button>
    </div>
  );
}

// ---- Chronicle Edit/Create Screen ----

function EditLogScreen({ mode = 'new', initial, onClose, onSave, onDelete }) {
  const [name, setName] = useSC(initial?.name || '');
  const isEdit = mode === 'edit';
  const title = isEdit ? 'Редактирование' : 'Новая хроника';
  const canSave = name.trim().length > 0;

  return (
    <div style={{
      flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column',
      background: 'var(--background)', overflow: 'hidden',
    }}>
      {/* Top bar — delete icon in trailing position (edit mode only) */}
      <div style={{
        height: 64, display: 'flex', alignItems: 'center',
        padding: '0 4px',
        background: 'var(--surface)',
        borderBottom: '1px solid var(--outline-variant)',
        flexShrink: 0,
      }}>
        <IconButton icon="close" onClick={onClose} />
        <div style={{
          flex: 1, padding: '0 8px',
          fontSize: 22, fontWeight: 500, lineHeight: '28px',
          color: 'var(--on-surface)',
        }}>{title}</div>
        {isEdit && <IconButton icon="delete" onClick={onDelete} color="var(--error)" />}
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 20px' }}>
        <ChronicleNameField
          value={name}
          onChange={setName}
          autoFocus
        />
        <button
          onClick={() => canSave && onSave({ name: name.trim() })}
          style={{
            marginTop: 20, width: '100%', height: 48,
            background: canSave ? 'var(--primary)' : 'var(--surface-variant)',
            color: canSave ? 'var(--on-primary)' : 'var(--on-surface-variant)',
            border: 'none', borderRadius: 24, cursor: canSave ? 'pointer' : 'default',
            fontFamily: 'Roboto', fontSize: 16, fontWeight: 500, letterSpacing: 0.1,
            transition: 'background 120ms, color 120ms',
          }}
        >Сохранить</button>
      </div>
    </div>
  );
}

function ChronicleNameField({ value, onChange, autoFocus }) {
  const [focused, setFocused] = useSC(false);
  const ref = useRC(null);
  const filled = value != null && value !== '';
  const floating = focused || filled;
  const borderColor = focused ? 'var(--primary)' : 'var(--outline)';
  const borderWidth = focused ? 2 : 1;

  useEC(() => {
    if (autoFocus && ref.current) ref.current.focus();
  }, [autoFocus]);

  return (
    <div style={{ position: 'relative' }}>
      <div
        onClick={() => ref.current && ref.current.focus()}
        style={{
          position: 'relative', minHeight: 56,
          border: `${borderWidth}px solid ${borderColor}`,
          borderRadius: 4, cursor: 'text',
          transition: 'border-color 120ms',
        }}
      >
        <div style={{
          position: 'absolute',
          left: 12, top: floating ? -8 : 16,
          padding: floating ? '0 4px' : 0,
          background: floating ? 'var(--background)' : 'transparent',
          fontFamily: 'Roboto',
          fontSize: floating ? 12 : 16,
          fontWeight: 400, letterSpacing: 0.4,
          color: focused ? 'var(--primary)' : 'var(--on-surface-variant)',
          transition: 'all 120ms',
          pointerEvents: 'none',
          lineHeight: floating ? '16px' : '24px',
        }}>Название хроники</div>

        <input
          ref={ref}
          value={value || ''}
          onChange={e => onChange(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={{
            width: '100%', height: 56,
            padding: '0 16px',
            border: 'none', outline: 'none', background: 'transparent',
            fontFamily: 'Roboto', fontSize: 16, fontWeight: 400, lineHeight: '24px',
            letterSpacing: 0.5, color: 'var(--on-surface)',
          }}
        />
      </div>
    </div>
  );
}

// ---- Logout confirmation dialog ----

function LogoutDialog({ open, onConfirm, onCancel }) {
  if (!open) return null;
  return (
    <>
      <div onClick={onCancel} style={{
        position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.32)', zIndex: 90,
      }} />
      <div style={{
        position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)',
        width: 312, background: 'var(--surface-container-low)',
        borderRadius: 28, padding: '24px', zIndex: 100,
        boxShadow: '0 8px 24px rgba(0,0,0,0.2)',
      }}>
        <div style={{
          fontSize: 24, fontWeight: 500, lineHeight: '32px',
          color: 'var(--on-surface)',
        }}>Выйти из аккаунта?</div>
        <div style={{
          marginTop: 16, fontSize: 14, lineHeight: '20px',
          color: 'var(--on-surface-variant)',
        }}>Данные хроник сохранятся на сервере. Вы сможете войти снова в любое время.</div>
        <div style={{ marginTop: 24, display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
          <button onClick={onCancel} style={{
            height: 40, padding: '0 16px', background: 'transparent',
            color: 'var(--primary)', border: 'none', borderRadius: 20, cursor: 'pointer',
            fontFamily: 'Roboto', fontSize: 14, fontWeight: 500,
          }}>Отмена</button>
          <button onClick={onConfirm} style={{
            height: 40, padding: '0 16px', background: 'var(--error)',
            color: 'var(--on-error)', border: 'none', borderRadius: 20, cursor: 'pointer',
            fontFamily: 'Roboto', fontSize: 14, fontWeight: 500,
          }}>Выйти</button>
        </div>
      </div>
    </>
  );
}

// ---- Delete confirmation dialog ----

function DeleteChronicleDialog({ open, name, onConfirm, onCancel }) {
  if (!open) return null;
  return (
    <>
      <div onClick={onCancel} style={{
        position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.32)', zIndex: 90,
      }} />
      <div style={{
        position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)',
        width: 312, background: 'var(--surface-container-low)',
        borderRadius: 28, padding: '24px', zIndex: 100,
        boxShadow: '0 8px 24px rgba(0,0,0,0.2)',
      }}>
        <span className="material-symbols-outlined" style={{
          fontSize: 24, color: 'var(--error)',
        }}>delete</span>
        <div style={{
          marginTop: 16, fontSize: 24, fontWeight: 500, lineHeight: '32px',
          color: 'var(--on-surface)',
        }}>Удалить хронику?</div>
        <div style={{
          marginTop: 16, fontSize: 14, lineHeight: '20px',
          color: 'var(--on-surface-variant)',
        }}>Хроника «{name}» и все её записи будут удалены без возможности восстановления.</div>
        <div style={{ marginTop: 24, display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
          <button onClick={onCancel} style={{
            height: 40, padding: '0 16px', background: 'transparent',
            color: 'var(--primary)', border: 'none', borderRadius: 20, cursor: 'pointer',
            fontFamily: 'Roboto', fontSize: 14, fontWeight: 500,
          }}>Отмена</button>
          <button onClick={onConfirm} style={{
            height: 40, padding: '0 16px', background: 'var(--error)',
            color: 'var(--on-error)', border: 'none', borderRadius: 20, cursor: 'pointer',
            fontFamily: 'Roboto', fontSize: 14, fontWeight: 500,
          }}>Удалить</button>
        </div>
      </div>
    </>
  );
}

Object.assign(window, {
  SAMPLE_CHRONICLES,
  LogListScreen, ChronicleCard,
  EditLogScreen, ChronicleNameField,
  LogoutDialog, DeleteChronicleDialog,
});
