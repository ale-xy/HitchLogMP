// history-data.jsx — sample edit-history data + helpers

// One entry per change. CREATE has `after`, DELETE has `before`,
// UPDATE has both (only the changed fields are required, but we keep snapshots
// of the affected fields for richer diff display).
const SAMPLE_HISTORY = [
  // ── Record 1 (START) ── short typo fix
  { id: 'h1', recordId: 1, editedAt: '2026-05-16T09:01', changeType: 'CREATE',
    after: { time: '2026-05-16T09:00', type: 'START', text: 'Стартовали' } },
  { id: 'h2', recordId: 1, editedAt: '2026-05-16T09:14', changeType: 'UPDATE',
    before: { text: 'Стартовали' },
    after:  { text: 'Выборг, Замковый остров. Стартовали по сигналу судьи.' } },

  // ── Record 4 (LIFT) ── time corrected + text expanded twice
  { id: 'h3', recordId: 4, editedAt: '2026-05-16T09:32', changeType: 'CREATE',
    after: { time: '2026-05-16T09:30', type: 'LIFT', text: 'Газель' } },
  { id: 'h4', recordId: 4, editedAt: '2026-05-16T09:36', changeType: 'UPDATE',
    before: { time: '2026-05-16T09:30', text: 'Газель' },
    after:  { time: '2026-05-16T09:31', text: 'Volvo XC60' } },
  { id: 'h5', recordId: 4, editedAt: '2026-05-16T10:51', changeType: 'UPDATE',
    before: { text: 'Volvo XC60' },
    after:  { text: 'Volvo XC60, Михаил, едет до Зеленогорска' } },

  // ── Record 7 (LIFT) ── originally logged as WALK, type corrected
  { id: 'h6', recordId: 7, editedAt: '2026-05-16T11:14', changeType: 'CREATE',
    after: { time: '2026-05-16T11:10', type: 'WALK', text: 'Идём по обочине' } },
  { id: 'h7', recordId: 7, editedAt: '2026-05-16T11:22', changeType: 'UPDATE',
    before: { time: '2026-05-16T11:10', type: 'WALK', text: 'Идём по обочине' },
    after:  { time: '2026-05-16T11:12', type: 'LIFT', text: 'Газель, водитель Андрей — везёт стройматериалы в Сестрорецк' } },

  // ── Record 8 (CHECKPOINT) ── judge name added
  { id: 'h8', recordId: 8, editedAt: '2026-05-16T12:07', changeType: 'CREATE',
    after: { time: '2026-05-16T12:05', type: 'CHECKPOINT', text: 'КП-1 Сестрорецк' } },
  { id: 'h9', recordId: 8, editedAt: '2026-05-16T12:25', changeType: 'UPDATE',
    before: { text: 'КП-1 Сестрорецк' },
    after:  { text: 'КП-1 Сестрорецк. Отметились у судьи Иванова. Время в норме.' } },

  // ── Record 99 (deleted-only, not in main list) ── mistakenly logged then removed
  { id: 'h10', recordId: 99, editedAt: '2026-05-16T14:30', changeType: 'CREATE',
    after: { time: '2026-05-16T14:25', type: 'CHECKPOINT', text: 'КП-2 — ошибочно отметился' } },
  { id: 'h11', recordId: 99, editedAt: '2026-05-16T15:45', changeType: 'DELETE',
    before: { time: '2026-05-16T14:25', type: 'CHECKPOINT', text: 'КП-2 — ошибочно отметился' } },

  // ── Record 22 (CHECKPOINT) ── time + text fixed after judge confirmation
  { id: 'h12', recordId: 22, editedAt: '2026-05-17T09:14', changeType: 'CREATE',
    after: { time: '2026-05-17T09:10', type: 'CHECKPOINT', text: 'КП-3 Лахта' } },
  { id: 'h13', recordId: 22, editedAt: '2026-05-17T09:20', changeType: 'UPDATE',
    before: { time: '2026-05-17T09:10', text: 'КП-3 Лахта' },
    after:  { time: '2026-05-17T09:12', text: 'КП-3 Лахта. Контрольный звонок штабу принят.' } },

  // ── Record 27 (FINISH) ── final timestamp corrected after judge sign-off
  { id: 'h14', recordId: 27, editedAt: '2026-05-17T10:48', changeType: 'CREATE',
    after: { time: '2026-05-17T10:45', type: 'FINISH', text: 'Финиш' } },
  { id: 'h15', recordId: 27, editedAt: '2026-05-17T11:02', changeType: 'UPDATE',
    before: { time: '2026-05-17T10:45', text: 'Финиш' },
    after:  { time: '2026-05-17T10:47', text: 'Дворцовая площадь. Финиш засвидетельствовал судья Петров. Итоговое время 25:47.' } },
];

// Synthetic "first-seen" snapshot for a record's history list — combines
// the original creation event (if present) with display ordering.
// Returns events asc by editedAt for a single recordId.
function recordHistoryAsc(recordId) {
  return SAMPLE_HISTORY
    .filter(h => h.recordId === recordId)
    .slice()
    .sort((a, b) => a.editedAt.localeCompare(b.editedAt));
}

// Final current state of a record (after last edit) — used to label rows
// in LogHistoryScreen with the record's "live" type + text.
function currentSnapshot(recordId) {
  const hist = recordHistoryAsc(recordId);
  // start from the CREATE.after, fold UPDATEs forward
  let state = null;
  for (const ev of hist) {
    if (ev.changeType === 'CREATE') state = { ...ev.after };
    else if (ev.changeType === 'UPDATE') state = { ...state, ...ev.after };
    else if (ev.changeType === 'DELETE') return { ...state, deleted: true };
  }
  return state;
}

// All record IDs that have any history, in order of original creation time
function recordIdsByCreation() {
  const byId = new Map();
  for (const h of SAMPLE_HISTORY) {
    if (h.changeType === 'CREATE' && !byId.has(h.recordId)) {
      byId.set(h.recordId, h.after.time || h.editedAt);
    }
  }
  return [...byId.entries()]
    .sort((a, b) => a[1].localeCompare(b[1])) // oldest record first
    .map(([id]) => id);
}

// Flat history, ascending by editedAt — for "by edit time" view
function allHistoryAsc() {
  return SAMPLE_HISTORY.slice().sort((a, b) => a.editedAt.localeCompare(b.editedAt));
}

// Human label for a change type
function changeTypeLabel(t) {
  return t === 'CREATE' ? 'Создана' : t === 'DELETE' ? 'Удалена' : 'Изменена';
}
function changeTypeIcon(t) {
  return t === 'CREATE' ? 'add' : t === 'DELETE' ? 'delete' : 'edit';
}
// Color role for the change-type chip — uses existing M3 token families
function changeTypeColors(t) {
  if (t === 'CREATE') return { bg: 'var(--primary-container)', fg: 'var(--on-primary-container)' };
  if (t === 'DELETE') return { bg: 'var(--error-container)',   fg: 'var(--on-error-container)' };
  return { bg: 'var(--secondary-container)', fg: 'var(--on-secondary-container)' };
}

// Format a full "dd MMM, HH:MM" for history timestamps
function formatHistoryTime(iso) {
  const d = new Date(iso);
  const MONTHS_SHORT = ['янв','фев','мар','апр','мая','июн','июл','авг','сен','окт','ноя','дек'];
  return `${d.getDate()} ${MONTHS_SHORT[d.getMonth()]} · ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
}

// Format just time
function fmtTime(iso) {
  if (!iso) return '';
  if (iso.length <= 5) return iso; // already HH:MM
  const d = new Date(iso);
  return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
}

Object.assign(window, {
  SAMPLE_HISTORY,
  recordHistoryAsc, currentSnapshot, recordIdsByCreation, allHistoryAsc,
  changeTypeLabel, changeTypeIcon, changeTypeColors,
  formatHistoryTime, fmtTime,
});
