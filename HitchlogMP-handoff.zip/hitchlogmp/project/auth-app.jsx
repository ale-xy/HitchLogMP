// auth-app.jsx — host shell for Auth screens

const { useState: useS5, useEffect: useE5 } = React;

const AUTH_TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "screen": "main",
  "variant": "classic",
  "darkMode": false
}/*EDITMODE-END*/;

function AuthApp() {
  const [tweaks, setTweak] = useTweaks(AUTH_TWEAK_DEFAULTS);
  const [snack, setSnack] = useS5(null);

  // Dark mode
  useE5(() => {
    if (tweaks.darkMode) {
      document.documentElement.style.setProperty('--background', '#11131A');
      document.documentElement.style.setProperty('--on-background', '#E4E2E9');
      document.documentElement.style.setProperty('--surface', '#191C24');
      document.documentElement.style.setProperty('--on-surface', '#E4E2E9');
      document.documentElement.style.setProperty('--surface-variant', '#252835');
      document.documentElement.style.setProperty('--on-surface-variant', '#C5C6D0');
      document.documentElement.style.setProperty('--outline', '#8E909A');
      document.documentElement.style.setProperty('--outline-variant', '#363946');
      document.documentElement.style.setProperty('--surface-container-low', '#1A1D26');
      document.documentElement.style.setProperty('--surface-container', '#1F2230');
      document.documentElement.style.setProperty('--primary', '#B0C4FF');
      document.documentElement.style.setProperty('--on-primary', '#012078');
      document.documentElement.style.setProperty('--primary-container', '#002C9F');
      document.documentElement.style.setProperty('--on-primary-container', '#D9E2FF');
      document.documentElement.style.setProperty('--secondary', '#FFCC00');
      document.documentElement.style.setProperty('--on-secondary', '#1A1A00');
      document.documentElement.style.setProperty('--auth-brand-bg', '#0E1B3D');
    } else {
      ['background','on-background','surface','on-surface','surface-variant','on-surface-variant','outline','outline-variant','surface-container-low','surface-container','primary','on-primary','primary-container','on-primary-container','secondary','on-secondary','auth-brand-bg']
        .forEach(k => document.documentElement.style.removeProperty('--' + k));
    }
  }, [tweaks.darkMode]);

  const handleLogin = (method) => {
    setSnack(`Вход: ${method}`);
  };

  return (
    <>
      <PhoneFrame>
        <AuthScreen
          key={tweaks.variant}
          onLogin={handleLogin}
          variant={tweaks.variant}
        />
        {snack && <AuthSnackbar message={snack} onDismiss={() => setSnack(null)} />}
      </PhoneFrame>

      <TweaksPanel>

        <TweakSection label="Тема" />
        <TweakToggle
          label="Тёмная тема"
          value={tweaks.darkMode}
          onChange={v => setTweak('darkMode', v)}
        />
      </TweaksPanel>
    </>
  );
}

function AuthSnackbar({ message, onDismiss }) {
  useE5(() => {
    const t = setTimeout(onDismiss, 2800);
    return () => clearTimeout(t);
  }, [message, onDismiss]);
  return (
    <div style={{
      position: 'absolute', left: 16, right: 16, bottom: 32,
      background: '#322F35', color: '#F4EFF4',
      padding: '14px 16px', borderRadius: 4,
      fontSize: 14, lineHeight: '20px',
      boxShadow: '0 6px 12px rgba(0,0,0,0.2)',
      zIndex: 80,
    }}>{message}</div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<AuthApp />);
