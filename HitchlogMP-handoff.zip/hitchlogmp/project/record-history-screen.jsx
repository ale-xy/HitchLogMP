// record-history-screen.jsx — История правок одной записи

const { useState: useRH, useMemo: useMH, useRef: useRefH, useEffect: useEffH } = React;

// ---------- Field diff row helpers ----------

// Inline type pill — used inside diffs when type changes
function TypePill({ type, strike }) {
  const def = RECORD_TYPES[type];
  if (!def) return null;
  const c = chipColors(def);
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '2px 10px 2px 2px', borderRadius: 100,
      background: 'var(--surface-variant)',
      color: 'var(--on-surface-variant)',
      fontSize: 13, fontWeight: 500,
      textDecoration: strike ? 'line-through' : 'none',
      opacity: strike ? 0.7 : 1,
      verticalAlign: 'middle',
    }}>
      <span style={{
        width: 20, height: 20, borderRadius: '50%',
        background: c.bg, color: c.fg,
        border: c.stroke ? `1px solid ${c.stroke}` : 'none',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <span className="material-symbols-outlined" style={{ fontSize: 13, color: c.fg }}>{def.icon}</span>
      </span>
      <span>{def.label}</span>
    </span>
  );
}

// Old → new for a value; renders strike + arrow + new
function DiffPair({ label, before, after, render }) {
  const r = render || (v => <span>{v}</span>);
  return (
    <div style={{ display: 'flex', gap: 12, padding: '2px 0' }}>
      <div style={{
        width: 64, flexShrink: 0,
        fontSize: 12, fontWeight: 500, letterSpacing: 0.4,
        color: 'var(--on-surface-variant)', textTransform: 'uppercase',
        paddingTop: 2,
      }}>{label}</div>
      <div style={{
        flex: 1, minWidth: 0,
        fontSize: 14, lineHeight: '20px', color: 'var(--on-surface)',
      }}>
        {before != null && (
          <span style={{
            color: 'var(--on-surface-variant)',
            textDecoration: 'line-through',
            textDecorationColor: 'var(--error)',
            textDecorationThickness: '1px',
          }}>{r(before)}</span>
        )}
        {before != null && after != null && (
          <span style={{ color: 'var(--on-surface-variant)', margin: '0 8px', userSelect: 'none' }}>→</span>
        )}
        {after != null && <span>{r(after)}</span>}
      </div>
    </div>
  );
}

// Diff body — pulls changed fields out of a history event and renders rows.
// `ev.changeType` ∈ {CREATE, UPDATE, DELETE}.
function ChangeDiff({ ev }) {
  const fields = [];
  const pushTime = (a, b) =>
    fields.push(<DiffPair key="time" label="Время" before={a} after={b}
      render={v => <span style={{ fontVariantNumeric: 'tabular-nums' }}>{fmtTime(v)}</span>} />);
  const pushType = (a, b) =>
    fields.push(<DiffPair key="type" label="Тип" before={a} after={b}
      render={v => <TypePill type={v} />} />);
  const pushText = (a, b) =>
    fields.push(<DiffPair key="text" label="Текст" before={a} after={b} />);

  if (ev.changeType === 'CREATE') {
    const s = ev.after || {};
    if (s.time) pushTime(null, s.time);
    if (s.type) pushType(null, s.type);
    if (s.text) pushText(null, s.text);
  } else if (ev.changeType === 'DELETE') {
    const s = ev.before || {};
    if (s.time) pushTime(s.time, null);
    if (s.type) pushType(s.type, null);
    if (s.text) pushText(s.text, null);
  } else {
    const b = ev.before || {}; const a = ev.after || {};
    if (a.time != null && a.time !== b.time) pushTime(b.time, a.time);
    if (a.type != null && a.type !== b.type) pushType(b.type, a.type);
    if (a.text != null && a.text !== b.text) pushText(b.text, a.text);
  }
  return <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>{fields}</div>;
}

// ---------- Change-type chip (small, inline) ----------

function ChangeTypeChip({ kind, compact }) {
  const c = changeTypeColors(kind);
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: compact ? '2px 8px 2px 6px' : '4px 10px 4px 6px',
      borderRadius: 100,
      background: c.bg, color: c.fg,
      fontSize: 12, fontWeight: 500, letterSpacing: 0.2,
    }}>
      <span className="material-symbols-outlined" style={{ fontSize: 14, color: c.fg }}>{changeTypeIcon(kind)}</span>
      <span>{changeTypeLabel(kind)}</span>
    </span>
  );
}

// ---------- Single version card with timeline rail ----------

function VersionCard({ ev, isLast }) {
  return (
    <div style={{ padding: '0 16px' }}>
      <div style={{
        background: 'var(--surface)',
        border: '1px solid var(--outline-variant)',
        borderRadius: 12,
        padding: '12px 14px 14px',
        marginBottom: 12,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
          <ChangeTypeChip kind={ev.changeType} />
          <span style={{
            fontSize: 12, fontWeight: 500, color: 'var(--on-surface-variant)',
            fontVariantNumeric: 'tabular-nums', letterSpacing: 0.3,
          }}>{formatHistoryTime(ev.editedAt)}</span>
        </div>
        <div style={{ marginTop: 10 }}>
          <ChangeDiff ev={ev} />
        </div>
      </div>
    </div>
  );
}

// ---------- Current-state hero card ----------

function CurrentStateCard({ snapshot, recordId }) {
  if (!snapshot) return null;
  const def = RECORD_TYPES[snapshot.type] || {};
  const c = chipColors(def);
  const deleted = snapshot.deleted;

  return (
    <div style={{
      margin: '12px 16px 16px', padding: '16px',
      background: deleted ? 'var(--error-container)' : 'var(--primary-container)',
      color: deleted ? 'var(--on-error-container)' : 'var(--on-primary-container)',
      borderRadius: 12,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{
          fontSize: 11, fontWeight: 600, letterSpacing: 0.6, textTransform: 'uppercase',
          opacity: 0.75,
        }}>{deleted ? 'Удалённая запись' : 'Текущее состояние'}</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, marginTop: 10 }}>
        <span style={{
          width: 40, height: 40, borderRadius: '50%',
          background: c.bg, color: c.fg,
          border: c.stroke ? `1px solid ${c.stroke}` : 'none',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        }}>
          <span className="material-symbols-outlined" style={{ fontSize: 22, color: c.fg }}>{def.icon}</span>
        </span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 8,
            textDecoration: deleted ? 'line-through' : 'none',
          }}>
            <span style={{ fontSize: 16, fontWeight: 500 }}>{def.label}</span>
            <span style={{ fontSize: 13, fontWeight: 500, fontVariantNumeric: 'tabular-nums', opacity: 0.85 }}>
              {fmtTime(snapshot.time)}
            </span>
          </div>
          {snapshot.text && (
            <div style={{
              marginTop: 4, fontSize: 14, lineHeight: '20px', opacity: 0.85,
              textDecoration: deleted ? 'line-through' : 'none',
            }}>{snapshot.text}</div>
          )}
        </div>
      </div>
    </div>
  );
}

// ---------- Main screen ----------

function RecordHistoryScreen({ recordId, onBack }) {
  const events = useMH(() => recordHistoryAsc(recordId), [recordId]);
  const snapshot = useMH(() => currentSnapshot(recordId), [recordId]);
  const [scrolled, setScrolled] = useRH(false);
  const scrollRef = useRefH(null);

  useEffH(() => {
    const el = scrollRef.current;
    if (!el) return;
    const fn = () => setScrolled(el.scrollTop > 4);
    el.addEventListener('scroll', fn);
    return () => el.removeEventListener('scroll', fn);
  }, []);

  const def = RECORD_TYPES[snapshot?.type] || {};

  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden',
      background: 'var(--background)', position: 'relative',
    }}>
      {/* top bar */}
      <div style={{
        flexShrink: 0,
        background: scrolled ? 'var(--surface-container)' : 'var(--surface)',
        transition: 'background 200ms',
        borderBottom: scrolled ? '1px solid var(--outline-variant)' : '1px solid transparent',
      }}>
        <div style={{ height: 64, display: 'flex', alignItems: 'center', padding: '4px 4px' }}>
          <IconButton icon="arrow_back" onClick={onBack} />
          <div style={{ flex: 1, minWidth: 0, paddingLeft: 4 }}>
            <div style={{ fontSize: 22, lineHeight: '28px', fontWeight: 500, color: 'var(--on-surface)' }}>История записи</div>
          </div>
        </div>
      </div>

      {/* body */}
      <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden' }}>
        <CurrentStateCard snapshot={snapshot} recordId={recordId} />

        <div style={{ padding: '4px 0 32px' }}>
          {events.map((ev, i) => (
            <VersionCard key={ev.id} ev={ev} isLast={i === events.length - 1} />
          ))}
          {events.length === 0 && (
            <div style={{
              padding: '64px 24px', textAlign: 'center', color: 'var(--on-surface-variant)',
              fontSize: 14,
            }}>Записей в истории нет</div>
          )}
        </div>
      </div>
    </div>
  );
}

function pluralVersion(n) {
  const m10 = n % 10, m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return 'версия';
  if ([2,3,4].includes(m10) && ![12,13,14].includes(m100)) return 'версии';
  return 'версий';
}

Object.assign(window, {
  RecordHistoryScreen, ChangeTypeChip, ChangeDiff, DiffPair, TypePill,
  VersionCard, CurrentStateCard, pluralVersion,
});
