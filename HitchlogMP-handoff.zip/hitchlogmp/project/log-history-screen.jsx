// log-history-screen.jsx — История правок всей хроники (два режима сортировки)

const { useState: useLH, useMemo: useMLH, useRef: useRefLH, useEffect: useEffLH } = React;

// ---------- Segmented control (Material 3 SegmentedButton, single-select) ----------

function SegmentedToggle({ value, onChange, options }) {
  return (
    <div style={{
      display: 'flex',
      border: '1px solid var(--outline)',
      borderRadius: 100,
      overflow: 'hidden',
      background: 'var(--surface)',
    }}>
      {options.map((opt, i) => {
        const selected = opt.value === value;
        return (
          <button
            key={opt.value}
            onClick={() => onChange(opt.value)}
            style={{
              flex: 1, minWidth: 0, height: 40,
              border: 'none',
              borderLeft: i === 0 ? 'none' : '1px solid var(--outline)',
              background: selected ? 'var(--secondary-container)' : 'transparent',
              color: selected ? 'var(--on-secondary-container)' : 'var(--on-surface)',
              cursor: 'pointer',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              fontFamily: 'Roboto', fontSize: 13, fontWeight: 500, letterSpacing: 0.1,
              padding: '0 12px',
            }}
          >
            {selected && (
              <span className="material-symbols-outlined" style={{ fontSize: 16 }}>check</span>
            )}
            <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{opt.label}</span>
          </button>
        );
      })}
    </div>
  );
}

// ---------- Compact change row (used in both modes) ----------

// Renders: record-type chip | record headline | change pill | timestamp
// Below: short diff summary (1 line, ellipsised when long)
function ChangeRow({ ev, onClick, showRecordChip = true }) {
  // UPDATE entries only carry the changed fields, so type is often absent on
  // the event itself — fall back to the record's live snapshot.
  const type = ev.after?.type || ev.before?.type || currentSnapshot(ev.recordId)?.type;
  const def = RECORD_TYPES[type] || {};
  const c = chipColors(def);
  const [pressed, setPressed] = useLH(false);

  // Short diff summary for the supporting line
  const summary = useMLH(() => {
    if (ev.changeType === 'CREATE') {
      const txt = ev.after?.text;
      return txt ? `«${truncate(txt, 60)}»` : 'Создана запись';
    }
    if (ev.changeType === 'DELETE') {
      const txt = ev.before?.text;
      return txt ? `Удалена: «${truncate(txt, 50)}»` : 'Запись удалена';
    }
    // UPDATE — list changed fields
    const b = ev.before || {}, a = ev.after || {};
    const fs = [];
    if (a.time != null && a.time !== b.time) fs.push(`время ${fmtTime(b.time)} → ${fmtTime(a.time)}`);
    if (a.type != null && a.type !== b.type) {
      const fromDef = RECORD_TYPES[b.type], toDef = RECORD_TYPES[a.type];
      fs.push(`тип ${fromDef?.label} → ${toDef?.label}`);
    }
    if (a.text != null && a.text !== b.text) fs.push(`текст обновлён`);
    return fs.join(' · ') || 'Без изменений';
  }, [ev]);

  return (
    <div
      onClick={onClick}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        display: 'flex', alignItems: 'flex-start', gap: 12,
        padding: '12px 16px', minHeight: 72,
        background: pressed ? 'rgba(26,59,143,0.08)' : 'transparent',
        cursor: onClick ? 'pointer' : 'default',
        borderBottom: '1px solid var(--outline-variant)',
        transition: 'background 80ms',
      }}
    >
      {showRecordChip && (
        <span style={{
          width: 36, height: 36, borderRadius: '50%',
          background: c.bg, color: c.fg,
          border: c.stroke ? `1px solid ${c.stroke}` : 'none',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          opacity: ev.changeType === 'DELETE' ? 0.6 : 1,
        }}>
          <span className="material-symbols-outlined" style={{ fontSize: 20, color: c.fg }}>{def.icon}</span>
        </span>
      )}

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <span style={{
            fontSize: 15, fontWeight: 500, lineHeight: '22px',
            color: 'var(--on-surface)',
            textDecoration: ev.changeType === 'DELETE' ? 'line-through' : 'none',
            opacity: ev.changeType === 'DELETE' ? 0.7 : 1,
          }}>{def.label}</span>
          <ChangeTypeChip kind={ev.changeType} compact />
        </div>
        <div style={{
          marginTop: 4, fontSize: 13, lineHeight: '18px',
          color: 'var(--on-surface-variant)',
          overflow: 'hidden', display: '-webkit-box',
          WebkitLineClamp: 2, WebkitBoxOrient: 'vertical',
        }}>{summary}</div>
      </div>

      <div style={{
        fontSize: 12, fontWeight: 500, color: 'var(--on-surface-variant)',
        fontVariantNumeric: 'tabular-nums', letterSpacing: 0.3,
        paddingTop: 10, textAlign: 'right', flexShrink: 0, whiteSpace: 'nowrap',
      }}>{fmtTime(ev.editedAt)}</div>
    </div>
  );
}

function truncate(s, n) {
  if (!s) return '';
  return s.length > n ? s.slice(0, n - 1).trimEnd() + '…' : s;
}

// Full-diff row for the flat "by edit time" view — shows the record's
// type chip + headline, change-type pill + timestamp, and the complete diff
// underneath (same InlineDiff used in the grouped view).
function FullChangeRow({ ev, onClick }) {
  const type = ev.after?.type || ev.before?.type || currentSnapshot(ev.recordId)?.type;
  const def = RECORD_TYPES[type] || {};
  const c = chipColors(def);
  const [pressed, setPressed] = useLH(false);
  const deleted = ev.changeType === 'DELETE';

  return (
    <div
      onClick={onClick}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        display: 'flex', alignItems: 'flex-start', gap: 12,
        padding: '14px 16px',
        background: pressed ? 'rgba(26,59,143,0.06)' : 'transparent',
        cursor: onClick ? 'pointer' : 'default',
        borderBottom: '1px solid var(--outline-variant)',
        transition: 'background 80ms',
      }}
    >
      <span style={{
        width: 36, height: 36, borderRadius: '50%',
        background: c.bg, color: c.fg,
        border: c.stroke ? `1px solid ${c.stroke}` : 'none',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        opacity: deleted ? 0.6 : 1, marginTop: 2,
      }}>
        <span className="material-symbols-outlined" style={{ fontSize: 20, color: c.fg }}>{def.icon}</span>
      </span>

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', minWidth: 0 }}>
            <span style={{
              fontSize: 15, fontWeight: 500, lineHeight: '22px',
              color: 'var(--on-surface)',
              textDecoration: deleted ? 'line-through' : 'none',
              opacity: deleted ? 0.7 : 1,
            }}>{def.label}</span>
            <ChangeTypeChip kind={ev.changeType} compact />
          </div>
          <span style={{
            fontSize: 12, fontWeight: 500, color: 'var(--on-surface-variant)',
            fontVariantNumeric: 'tabular-nums', letterSpacing: 0.3,
            flexShrink: 0,
          }}>{fmtTime(ev.editedAt)}</span>
        </div>
        <InlineDiff ev={ev} />
      </div>
    </div>
  );
}

// ---------- Mode 1: flat, sorted by edit time, date-grouped ----------

function FlatByTime({ onPick }) {
  const events = useMLH(() => allHistoryAsc(), []);

  // Group by date of editedAt
  const groups = useMLH(() => {
    const map = new Map();
    for (const e of events) {
      const k = e.editedAt.slice(0, 10);
      if (!map.has(k)) map.set(k, []);
      map.get(k).push(e);
    }
    return [...map.entries()].map(([k, items]) => ({ key: k, iso: items[0].editedAt, items }));
  }, [events]);

  return (
    <div>
      {groups.map(g => (
        <div key={g.key}>
          <DateHeader iso={g.iso} />
          <div style={{
            background: 'var(--surface)',
            margin: '0 16px 8px',
            borderRadius: 12,
            overflow: 'hidden',
            border: '1px solid var(--outline-variant)',
          }}>
            {g.items.map((ev, i) => (
              <FullChangeRow
                key={ev.id}
                ev={ev}
                onClick={() => onPick && onPick(ev)}
              />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// ---------- Mode 2: grouped by record, sorted by original creation ----------

function GroupedByRecord({ onPick, onOpenRecord }) {
  const recordIds = useMLH(() => recordIdsByCreation(), []);

  return (
    <div style={{ padding: '8px 0 32px' }}>
      {recordIds.map(rid => {
        const events = recordHistoryAsc(rid); // earliest → latest inside section
        const live = currentSnapshot(rid);
        return (
          <RecordHistoryGroup
            key={rid}
            recordId={rid}
            live={live}
            events={events}
            onPick={onPick}
            onOpenRecord={onOpenRecord}
          />
        );
      })}
    </div>
  );
}

function RecordHistoryGroup({ recordId, live, events, onPick, onOpenRecord }) {
  const def = RECORD_TYPES[live?.type] || {};
  const c = chipColors(def);
  const deleted = live?.deleted;
  const firstCreate = events.find(e => e.changeType === 'CREATE');
  const originalTime = firstCreate?.after?.time;

  return (
    <div style={{
      margin: '12px 16px 4px',
      background: 'var(--surface)',
      borderRadius: 16,
      border: '1px solid var(--outline-variant)',
      overflow: 'hidden',
    }}>
      {/* Record header — links to record history detail */}
      <div
        onClick={() => onOpenRecord && onOpenRecord(recordId)}
        style={{
          display: 'flex', alignItems: 'center', gap: 12,
          padding: '14px 16px',
          background: deleted ? 'var(--error-container)' : 'var(--surface-container-low)',
          color: deleted ? 'var(--on-error-container)' : 'var(--on-surface)',
          cursor: onOpenRecord ? 'pointer' : 'default',
        }}
      >
        <span style={{
          width: 36, height: 36, borderRadius: '50%',
          background: c.bg, color: c.fg,
          border: c.stroke ? `1px solid ${c.stroke}` : 'none',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          opacity: deleted ? 0.65 : 1,
        }}>
          <span className="material-symbols-outlined" style={{ fontSize: 20, color: c.fg }}>{def.icon}</span>
        </span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            display: 'flex', alignItems: 'baseline', gap: 8,
          }}>
            <span style={{
              fontSize: 15, fontWeight: 500, lineHeight: '20px',
              textDecoration: deleted ? 'line-through' : 'none',
              opacity: deleted ? 0.7 : 1,
            }}>{def.label}</span>
            {originalTime && (
              <span style={{
                fontSize: 12, fontWeight: 500,
                color: deleted ? 'inherit' : 'var(--on-surface-variant)',
                opacity: 0.75, fontVariantNumeric: 'tabular-nums',
              }}>· {fmtTime(originalTime)}</span>
            )}
          </div>
          {live?.text && (
            <div style={{
              marginTop: 2,
              fontSize: 13, lineHeight: '18px',
              color: deleted ? 'inherit' : 'var(--on-surface-variant)',
              opacity: 0.85,
              textDecoration: deleted ? 'line-through' : 'none',
              overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis',
            }}>{live.text}</div>
          )}
        </div>
        <span style={{
          padding: '4px 10px', borderRadius: 100,
          background: deleted ? 'rgba(0,0,0,0.06)' : 'var(--primary-container)',
          color: deleted ? 'inherit' : 'var(--on-primary-container)',
          fontSize: 11, fontWeight: 600, letterSpacing: 0.3,
          fontVariantNumeric: 'tabular-nums', flexShrink: 0,
        }}>{events.length}</span>
      </div>

      {/* Events list inside this record */}
      <div>
        {events.map((ev, i) => (
          <div key={ev.id} style={{
            padding: '10px 16px 12px',
            borderTop: '1px solid var(--outline-variant)',
            cursor: onPick ? 'pointer' : 'default',
          }}
            onClick={() => onPick && onPick(ev)}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
              <ChangeTypeChip kind={ev.changeType} compact />
              <span style={{
                fontSize: 12, fontWeight: 500,
                color: 'var(--on-surface-variant)', fontVariantNumeric: 'tabular-nums',
                letterSpacing: 0.3,
              }}>{formatHistoryTime(ev.editedAt)}</span>
            </div>
            <InlineDiff ev={ev} />
          </div>
        ))}
      </div>
    </div>
  );
}

// Compact one-line diff for grouped view
function InlineDiff({ ev }) {
  const rows = [];
  if (ev.changeType === 'CREATE') {
    const s = ev.after || {};
    if (s.text) rows.push(<span key="t" style={{ color: 'var(--on-surface)' }}>«{s.text}»</span>);
    else rows.push(<span key="t" style={{ color: 'var(--on-surface-variant)' }}>Создана запись</span>);
  } else if (ev.changeType === 'DELETE') {
    rows.push(<span key="d" style={{ color: 'var(--on-surface-variant)' }}>Запись удалена</span>);
  } else {
    const b = ev.before || {}, a = ev.after || {};
    if (a.time != null && a.time !== b.time) {
      rows.push(
        <div key="time" style={{ fontVariantNumeric: 'tabular-nums' }}>
          <s style={{ color: 'var(--on-surface-variant)', textDecorationColor: 'var(--error)' }}>{fmtTime(b.time)}</s>
          <span style={{ margin: '0 6px', color: 'var(--on-surface-variant)' }}>→</span>
          <span style={{ color: 'var(--on-surface)' }}>{fmtTime(a.time)}</span>
        </div>
      );
    }
    if (a.type != null && a.type !== b.type) {
      rows.push(
        <div key="type" style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
          <TypePill type={b.type} strike />
          <span style={{ color: 'var(--on-surface-variant)' }}>→</span>
          <TypePill type={a.type} />
        </div>
      );
    }
    if (a.text != null && a.text !== b.text) {
      rows.push(
        <div key="text">
          <s style={{ color: 'var(--on-surface-variant)', textDecorationColor: 'var(--error)' }}>{b.text}</s>
          <div style={{ color: 'var(--on-surface)', marginTop: 2 }}>{a.text}</div>
        </div>
      );
    }
  }
  return <div style={{ marginTop: 6, display: 'flex', flexDirection: 'column', gap: 4, fontSize: 13, lineHeight: '18px' }}>{rows}</div>;
}

// ---------- Main screen ----------

function LogHistoryScreen({ sortMode, onChangeMode, logName, onBack, onPickEvent, onOpenRecord }) {
  const [scrolled, setScrolled] = useLH(false);
  const scrollRef = useRefLH(null);

  useEffLH(() => {
    const el = scrollRef.current;
    if (!el) return;
    const fn = () => setScrolled(el.scrollTop > 4);
    el.addEventListener('scroll', fn);
    return () => el.removeEventListener('scroll', fn);
  }, []);

  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden',
      background: 'var(--background)', position: 'relative',
    }}>
      {/* top bar */}
      <div style={{
        flexShrink: 0,
        background: scrolled ? 'var(--surface-container)' : 'var(--surface)',
        transition: 'background 200ms',
        borderBottom: scrolled ? '1px solid var(--outline-variant)' : '1px solid transparent',
      }}>
        <div style={{ height: 64, display: 'flex', alignItems: 'center', padding: '4px 4px' }}>
          <IconButton icon="arrow_back" onClick={onBack} />
          <div style={{ flex: 1, minWidth: 0, paddingLeft: 4 }}>
            <div style={{ fontSize: 22, lineHeight: '28px', fontWeight: 500, color: 'var(--on-surface)' }}>{logName}</div>
          </div>
        </div>
      </div>

      {/* segmented control */}
      <div style={{ padding: '12px 16px 4px', background: 'var(--background)', flexShrink: 0 }}>
        <SegmentedToggle
          value={sortMode}
          onChange={onChangeMode}
          options={[
            { value: 'by-time',   label: 'По времени правок' },
            { value: 'by-record', label: 'По записям' },
          ]}
        />
      </div>

      {/* body */}
      <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden' }}>
        {sortMode === 'by-time'
          ? <FlatByTime onPick={onPickEvent} />
          : <GroupedByRecord onPick={onPickEvent} onOpenRecord={onOpenRecord} />}
        <div style={{ height: 24 }} />
      </div>
    </div>
  );
}

function pluralEdit(n) {
  const m10 = n % 10, m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return 'правка';
  if ([2,3,4].includes(m10) && ![12,13,14].includes(m100)) return 'правки';
  return 'правок';
}
function pluralRecord2(n) {
  const m10 = n % 10, m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return 'записи';
  if ([2,3,4].includes(m10) && ![12,13,14].includes(m100)) return 'записях';
  return 'записях';
}

Object.assign(window, {
  LogHistoryScreen, SegmentedToggle, ChangeRow,
  FlatByTime, GroupedByRecord, RecordHistoryGroup, InlineDiff,
});
