// auth-screen.jsx — Auth screens for HitchLogMP

const { useState: useAS, useRef: useAR, useEffect: useAE, useCallback: useAC } = React;

// ---- Filled TextField (Material 3) ----

function FilledField({ label, value, onChange, type = 'text', autoFocus, error, trailing }) {
  const [focused, setFocused] = useAS(false);
  const [showPw, setShowPw] = useAS(false);
  const ref = useAR(null);
  const filled = value != null && value !== '';
  const floating = focused || filled;
  const isPassword = type === 'password';
  const inputType = isPassword ? (showPw ? 'text' : 'password') : type;

  useAE(() => {
    if (autoFocus && ref.current) ref.current.focus();
  }, [autoFocus]);

  const accentColor = error ? 'var(--error)' : (focused ? 'var(--primary)' : 'var(--on-surface-variant)');

  return (
    <div style={{ position: 'relative' }}>
      <div
        onClick={() => ref.current?.focus()}
        style={{
          position: 'relative', minHeight: 56,
          background: 'var(--surface-container)',
          borderRadius: '4px 4px 0 0',
          cursor: 'text',
        }}
      >
        {/* Label */}
        <div style={{
          position: 'absolute',
          left: 16, top: floating ? 8 : 16,
          fontFamily: 'Roboto',
          fontSize: floating ? 12 : 16,
          fontWeight: 400, letterSpacing: 0.4,
          color: accentColor,
          transition: 'all 120ms',
          pointerEvents: 'none',
          lineHeight: floating ? '16px' : '24px',
        }}>{label}</div>

        <input
          ref={ref}
          value={value || ''}
          onChange={e => onChange(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          type={inputType}
          style={{
            width: '100%', height: 56,
            padding: floating ? '24px 16px 8px' : '16px',
            paddingRight: isPassword ? 48 : 16,
            border: 'none', outline: 'none', background: 'transparent',
            fontFamily: 'Roboto', fontSize: 16, fontWeight: 400, lineHeight: '24px',
            letterSpacing: 0.5, color: 'var(--on-surface)',
          }}
        />

        {/* Password toggle */}
        {isPassword && (
          <button onClick={(e) => { e.stopPropagation(); setShowPw(!showPw); }} style={{
            position: 'absolute', right: 4, top: 4,
            width: 48, height: 48, border: 'none', background: 'transparent',
            borderRadius: '50%', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <span className="material-symbols-outlined" style={{ fontSize: 20, color: 'var(--on-surface-variant)' }}>
              {showPw ? 'visibility_off' : 'visibility'}
            </span>
          </button>
        )}

        {/* Bottom line */}
        <div style={{
          position: 'absolute', left: 0, right: 0, bottom: 0,
          height: focused ? 2 : 1,
          background: error ? 'var(--error)' : (focused ? 'var(--primary)' : 'var(--on-surface-variant)'),
          transition: 'all 120ms',
        }} />
      </div>
      {error && (
        <div style={{
          fontSize: 12, lineHeight: '16px', color: 'var(--error)',
          padding: '4px 16px 0', fontFamily: 'Roboto',
        }}>{error}</div>
      )}
    </div>
  );
}

// ---- Auth Buttons ----

function AuthButton({ label, icon, iconSvg, onClick, variant = 'filled', style: extraStyle }) {
  const [pressed, setPressed] = useAS(false);

  const baseStyles = {
    filled: {
      background: pressed ? 'var(--primary-container)' : 'var(--primary)',
      color: pressed ? 'var(--on-primary-container)' : 'var(--on-primary)',
    },
    tonal: {
      background: pressed ? 'var(--primary)' : 'var(--primary-container)',
      color: pressed ? 'var(--on-primary)' : 'var(--on-primary-container)',
    },
    outlined: {
      background: pressed ? 'var(--surface-container)' : 'transparent',
      color: 'var(--on-surface)',
      border: '1px solid var(--outline)',
    },
    text: {
      background: pressed ? 'var(--surface-container)' : 'transparent',
      color: 'var(--primary)',
    },
  };

  const s = baseStyles[variant] || baseStyles.filled;

  return (
    <button
      onClick={onClick}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      style={{
        width: '100%', height: 48, display: 'flex', alignItems: 'center',
        justifyContent: 'center', gap: 10,
        border: 'none', borderRadius: 24, cursor: 'pointer',
        fontFamily: 'Roboto', fontSize: 16, fontWeight: 500, letterSpacing: 0.1,
        transition: 'all 100ms',
        ...s,
        ...extraStyle,
      }}
    >
      {iconSvg && <span style={{ display: 'flex', flexShrink: 0 }} dangerouslySetInnerHTML={{ __html: iconSvg }} />}
      {icon && <span className="material-symbols-outlined" style={{ fontSize: 20 }}>{icon}</span>}
      {label}
    </button>
  );
}

// Brand SVGs (small, inline)
const GOOGLE_SVG = `<svg width="20" height="20" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59a14.5 14.5 0 010-9.18l-7.98-6.19a24.01 24.01 0 000 21.56l7.98-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>`;
const APPLE_SVG = `<svg width="20" height="20" viewBox="0 0 24 24"><path fill="currentColor" d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.52-3.23 0-1.44.62-2.2.44-3.06-.4C3.79 16.17 4.36 9.05 8.93 8.8c1.27.06 2.15.72 2.88.76.97-.2 1.9-.76 2.93-.7 1.24.1 2.17.57 2.79 1.45-2.56 1.53-1.95 4.89.58 5.83-.5 1.3-.72 1.88-1.36 3.03-.71 1.13-1.71 2.27-2.7 2.11zM12.59 8.7c-.15-2.09 1.53-3.87 3.47-4.06.28 2.28-2.04 4.2-3.47 4.06z"/></svg>`;

// ---- Main Auth Screen ----

function AuthScreen({ onLogin, variant = 'classic' }) {
  const [screen, setScreen] = useAS('main'); // main | email-login | email-register | forgot | forgot-sent
  const [email, setEmail] = useAS('');
  const [password, setPassword] = useAS('');
  const [confirmPw, setConfirmPw] = useAS('');
  const [errors, setErrors] = useAS({});
  const [loading, setLoading] = useAS(false);

  const resetFields = () => { setEmail(''); setPassword(''); setConfirmPw(''); setErrors({}); };

  const validateEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);

  const handleEmailLogin = () => {
    const errs = {};
    if (!validateEmail(email)) errs.email = 'Некорректный email';
    if (password.length < 6) errs.password = 'Минимум 6 символов';
    setErrors(errs);
    if (Object.keys(errs).length === 0) {
      setLoading(true);
      setTimeout(() => { setLoading(false); onLogin?.('email'); }, 800);
    }
  };

  const handleRegister = () => {
    const errs = {};
    if (!validateEmail(email)) errs.email = 'Некорректный email';
    if (password.length < 6) errs.password = 'Минимум 6 символов';
    if (confirmPw !== password) errs.confirm = 'Пароли не совпадают';
    setErrors(errs);
    if (Object.keys(errs).length === 0) {
      setLoading(true);
      setTimeout(() => { setLoading(false); onLogin?.('email'); }, 800);
    }
  };

  const handleForgot = () => {
    const errs = {};
    if (!validateEmail(email)) errs.email = 'Некорректный email';
    setErrors(errs);
    if (Object.keys(errs).length === 0) {
      setLoading(true);
      setTimeout(() => { setLoading(false); setScreen('forgot-sent'); }, 800);
    }
  };

  // ---- Render screens ----

  if (screen === 'forgot-sent') {
    return (
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--background)' }}>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '32px 24px', textAlign: 'center' }}>
          <div style={{
            width: 64, height: 64, borderRadius: '50%',
            background: 'var(--primary-container)', color: 'var(--on-primary-container)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 24,
          }}>
            <span className="material-symbols-outlined" style={{ fontSize: 32 }}>mark_email_read</span>
          </div>
          <div style={{ fontSize: 22, fontWeight: 500, color: 'var(--on-surface)', marginBottom: 12 }}>
            Письмо отправлено
          </div>
          <div style={{ fontSize: 14, lineHeight: '20px', color: 'var(--on-surface-variant)', maxWidth: 280 }}>
            Ссылка для сброса пароля отправлена на <span style={{ fontWeight: 500, color: 'var(--on-surface)' }}>{email}</span>. Проверьте почту и следуйте инструкциям.
          </div>
          <button
            onClick={() => { resetFields(); setScreen('main'); }}
            style={{
              marginTop: 32, height: 40, padding: '0 24px',
              background: 'transparent', color: 'var(--primary)',
              border: 'none', borderRadius: 20, cursor: 'pointer',
              fontFamily: 'Roboto', fontSize: 14, fontWeight: 500,
            }}
          >Вернуться к входу</button>
        </div>
      </div>
    );
  }

  if (screen === 'forgot') {
    return (
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--background)' }}>
        <div style={{
          height: 64, display: 'flex', alignItems: 'center', padding: '0 4px',
          background: 'var(--surface)', flexShrink: 0,
        }}>
          <IconButton icon="arrow_back" onClick={() => { resetFields(); setScreen('email-login'); }} />
          <div style={{ fontSize: 22, fontWeight: 500, color: 'var(--on-surface)', paddingLeft: 4 }}>
            Сброс пароля
          </div>
        </div>
        <div style={{ flex: 1, padding: '24px 20px' }}>
          <div style={{ fontSize: 14, lineHeight: '20px', color: 'var(--on-surface-variant)', marginBottom: 24 }}>
            Введите email, указанный при регистрации. Мы отправим ссылку для сброса пароля.
          </div>
          <FilledField label="Email" value={email} onChange={setEmail} type="email" autoFocus error={errors.email} />
          <button
            onClick={handleForgot}
            disabled={loading}
            style={{
              marginTop: 24, width: '100%', height: 48,
              background: 'var(--primary)', color: 'var(--on-primary)',
              border: 'none', borderRadius: 24, cursor: 'pointer',
              fontFamily: 'Roboto', fontSize: 16, fontWeight: 500,
              opacity: loading ? 0.7 : 1,
            }}
          >{loading ? 'Отправка...' : 'Отправить ссылку'}</button>
        </div>
      </div>
    );
  }

  if (screen === 'email-register') {
    return (
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--background)' }}>
        <div style={{
          height: 64, display: 'flex', alignItems: 'center', padding: '0 4px',
          background: 'var(--surface)', flexShrink: 0,
        }}>
          <IconButton icon="arrow_back" onClick={() => { resetFields(); setScreen('main'); }} />
          <div style={{ fontSize: 22, fontWeight: 500, color: 'var(--on-surface)', paddingLeft: 4 }}>
            Регистрация
          </div>
        </div>
        <div style={{ flex: 1, overflowY: 'auto', padding: '24px 20px' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <FilledField label="Email" value={email} onChange={setEmail} type="email" autoFocus error={errors.email} />
            <FilledField label="Пароль" value={password} onChange={setPassword} type="password" error={errors.password} />
            <FilledField label="Повторите пароль" value={confirmPw} onChange={setConfirmPw} type="password" error={errors.confirm} />
          </div>
          <button
            onClick={handleRegister}
            disabled={loading}
            style={{
              marginTop: 24, width: '100%', height: 48,
              background: 'var(--primary)', color: 'var(--on-primary)',
              border: 'none', borderRadius: 24, cursor: 'pointer',
              fontFamily: 'Roboto', fontSize: 16, fontWeight: 500,
              opacity: loading ? 0.7 : 1,
            }}
          >{loading ? 'Создание...' : 'Создать аккаунт'}</button>
          <div style={{ marginTop: 16, textAlign: 'center' }}>
            <button onClick={() => { resetFields(); setScreen('email-login'); }} style={{
              background: 'none', border: 'none', color: 'var(--primary)',
              fontFamily: 'Roboto', fontSize: 14, fontWeight: 500, cursor: 'pointer',
            }}>Уже есть аккаунт? Войти</button>
          </div>
        </div>
      </div>
    );
  }

  if (screen === 'email-login') {
    return (
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--background)' }}>
        <div style={{
          height: 64, display: 'flex', alignItems: 'center', padding: '0 4px',
          background: 'var(--surface)', flexShrink: 0,
        }}>
          <IconButton icon="arrow_back" onClick={() => { resetFields(); setScreen('main'); }} />
          <div style={{ fontSize: 22, fontWeight: 500, color: 'var(--on-surface)', paddingLeft: 4 }}>
            Вход по email
          </div>
        </div>
        <div style={{ flex: 1, overflowY: 'auto', padding: '24px 20px' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <FilledField label="Email" value={email} onChange={setEmail} type="email" autoFocus error={errors.email} />
            <FilledField label="Пароль" value={password} onChange={setPassword} type="password" error={errors.password} />
          </div>
          <div style={{ marginTop: 8, textAlign: 'right' }}>
            <button onClick={() => { setErrors({}); setScreen('forgot'); }} style={{
              background: 'none', border: 'none', color: 'var(--primary)',
              fontFamily: 'Roboto', fontSize: 14, fontWeight: 500, cursor: 'pointer',
            }}>Забыли пароль?</button>
          </div>
          <button
            onClick={handleEmailLogin}
            disabled={loading}
            style={{
              marginTop: 16, width: '100%', height: 48,
              background: 'var(--primary)', color: 'var(--on-primary)',
              border: 'none', borderRadius: 24, cursor: 'pointer',
              fontFamily: 'Roboto', fontSize: 16, fontWeight: 500,
              opacity: loading ? 0.7 : 1,
            }}
          >{loading ? 'Вход...' : 'Войти'}</button>
          <div style={{ marginTop: 16, textAlign: 'center' }}>
            <button onClick={() => { resetFields(); setScreen('email-register'); }} style={{
              background: 'none', border: 'none', color: 'var(--primary)',
              fontFamily: 'Roboto', fontSize: 14, fontWeight: 500, cursor: 'pointer',
            }}>Нет аккаунта? Зарегистрироваться</button>
          </div>
        </div>
      </div>
    );
  }

  // ---- Main login screen ----

  const isCompact = true;
  const isBrand = false;

  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column',
      background: isBrand ? 'var(--auth-brand-bg, var(--primary))' : 'var(--background)',
      overflow: 'hidden',
    }}>
      {/* Top area — branding */}
      <div style={{
        flex: isCompact ? '0 0 auto' : '1 1 0',
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: isCompact ? 'flex-start' : 'center',
        padding: isCompact ? '80px 24px 32px' : '0 24px',
        minHeight: isCompact ? undefined : 0,
      }}>
        <img
          src="GMA-logo.png"
          alt="ГМА"
          style={{
            width: isBrand ? 80 : (isCompact ? 64 : 72),
            height: isBrand ? 80 : (isCompact ? 64 : 72),
            marginBottom: 16,

          }}
        />
        <div style={{
          fontSize: isBrand ? 32 : (isCompact ? 28 : 30),
          fontWeight: 500,
          color: isBrand ? 'var(--on-primary)' : 'var(--on-surface)',
          letterSpacing: -0.5,
          textAlign: 'center',
        }}>HitchLog</div>
        <div style={{
          fontSize: 14, lineHeight: '20px',
          color: isBrand ? 'rgba(255,255,255,0.6)' : 'var(--on-surface-variant)',
          marginTop: 6, textAlign: 'center',
        }}>Гильдия Мастеров Автостопа</div>
      </div>

      {/* Buttons area */}
      <div style={{
        flexShrink: 0,
        padding: isCompact ? '0 24px 40px' : '0 24px 40px',
        ...(isBrand ? {
          background: 'var(--background)',
          borderRadius: '24px 24px 0 0',
          padding: '28px 24px 40px',
        } : {}),
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {/* Email */}
          <AuthButton
            label="Войти через Email"
            icon="mail"
            variant={isBrand ? 'filled' : 'tonal'}
            onClick={() => { resetFields(); setScreen('email-login'); }}
          />

          {/* Google */}
          <AuthButton
            label="Войти через Google"
            iconSvg={GOOGLE_SVG}
            variant="outlined"
            onClick={() => onLogin?.('google')}
          />

          {/* Apple */}
          <AuthButton
            label="Войти через Apple"
            iconSvg={APPLE_SVG}
            variant="outlined"
            onClick={() => onLogin?.('apple')}
            style={isBrand ? {} : {}}
          />

          {/* Divider */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 12,
            padding: '4px 0',
          }}>
            <div style={{ flex: 1, height: 1, background: 'var(--outline-variant)' }} />
            <span style={{ fontSize: 12, color: 'var(--on-surface-variant)', fontFamily: 'Roboto', letterSpacing: 0.4 }}>или</span>
            <div style={{ flex: 1, height: 1, background: 'var(--outline-variant)' }} />
          </div>

          {/* Anonymous */}
          <AuthButton
            label="Войти анонимно"
            icon="person_off"
            variant="text"
            onClick={() => onLogin?.('anonymous')}
          />
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { AuthScreen, FilledField, AuthButton, GOOGLE_SVG, APPLE_SVG });
