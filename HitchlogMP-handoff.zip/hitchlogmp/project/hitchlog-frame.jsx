// hitchlog-frame.jsx — PhoneFrame + NavBar (shared across HitchLog screens)

function PhoneFrame({ children, accent }) {
  return (
    <div style={{
      width: 412, height: 892, borderRadius: 44, padding: 10,
      background: '#1d1b20',
      boxShadow: '0 40px 80px rgba(0,0,0,0.45), 0 0 0 1px rgba(255,255,255,0.06) inset',
      position: 'relative', flexShrink: 0,
    }}>
      <div style={{
        width: '100%', height: '100%', borderRadius: 36, overflow: 'hidden',
        background: 'var(--background)', display: 'flex', flexDirection: 'column',
        position: 'relative',
      }}>
        <StatusBar />
        {children}
        <NavBar />
      </div>
      {/* camera punch-hole */}
      <div style={{
        position: 'absolute', left: '50%', top: 22, transform: 'translateX(-50%)',
        width: 18, height: 18, borderRadius: '50%', background: '#000', zIndex: 100,
      }} />
    </div>
  );
}

function NavBar() {
  return (
    <div style={{
      height: 24, flexShrink: 0,
      background: 'var(--background)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <div style={{ width: 108, height: 4, borderRadius: 2, background: 'var(--on-surface)', opacity: 0.4 }} />
    </div>
  );
}

Object.assign(window, { PhoneFrame, NavBar });
